import { notFound } from "next/navigation";
import { getPostBySlug } from "@/lib/actions/posts";
import { markdownToHtml, markdownToToc } from "@/lib/markdownToHtml";
import markdownStyles from "@/styles//markdown.module.css";
import PostBackButton from "@/components/sections/postBackButton";
import PostTableOfContents from "@/components/sections/postToc";
import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

type Params = {
    params: {
        slug: string;
    };
};

export default async function Post({ params }: Params) {
    const post = await getPostBySlug(params.slug);

    if (!post) {
        return notFound();
    }

    const content = await markdownToHtml(post.content || "");
    const headings = await markdownToToc(post.content || "");

    const accentColor = post.accentColor ? post.accentColor : "#2b2b2b";

    return (
        <main className="relative w-full min-h-screen pt-48 lg:px-20 px-8 flex flex-col">
            <div className="fixed top-0 h-[1.5px] mb-[-1px] w-full" style={{ background: `linear-gradient(to right, transparent 10%, ${accentColor} 50%, transparent 90%)` }} />
            <div className="w-full flex lg:hidden flex-row items-center justify-between">
                <div className="w-full flex items-center justify-start">
                    <PostBackButton />
                </div>
                <div className="w-full flex items-center justify-end">
                    <PostTableOfContents headings={headings} />
                </div>
            </div>
            <div className="w-full mt-8 lg:mt-0 flex flex-row items-start justify-between">
                <div className="hidden lg:flex w-full justify-center mt-8">
                    <PostBackButton />
                </div>
                <article className="max-w-4xl mx-auto">
                    <header>
                        {post.coverImage && (
                            <div className="w-full relative rounded-xl overflow-hidden">
                                <Image className="rounded-xl" src={post.coverImage} alt={post.title} width={800} height={400} style={{ width: "100%", height: "auto", objectFit: "cover" }} />
                            </div>
                        )}
                        <div className="w-full flex flex-row items-center justify-between mt-8">
                            <div className="flex flex-col items-start justify-start">
                                <h1 className="text-4xl font-bold flex flex-row items-center justify-start">
                                    {post.title}
                                    {post.link && (
                                    <Button variant="link">
                                        <Link href={post.link as any} target="_blank" rel="noopener noreferrer"><ExternalLink className="w-4 h-4" /></Link>
                                    </Button>
                                    )}
                                </h1>
                                {post.subtitle && <h2 className="text-2xl font-light">{post.subtitle}</h2>}
                            </div>
                            <div className="hidden sm:flex flex-col flex-1 items-end justify-end">
                                {post.author && (
                                <div className="w-full flex flex-row items-center justify-end">
                                    <div className="w-6 h-6 mr-2">
                                        <Image className="rounded-full" src={post.author.avatar} alt={post.author.name} width={40} height={40} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                                    </div>
                                    <Link href={post.author.url as any} target="_blank" rel="noopener noreferrer" className="text-lg font-light">{post.author.name}</Link>
                                </div>
                                )}
                                <p className="text-lg font-light">{post.date}</p>
                                {post.tags && (
                                    <div className="flex flex-row items-center justify-end flex-wrap">
                                        {post.tags.map((tag, index) => (
                                            <p key={index} className="text-lg font-light text-gray-400">{tag}
                                            {/*
                                            {index !== (post.tags?.length ?? 0) - 1 && <span className="text-lg font-light text-gray-400 mr-2">,</span>}
                                            */}
                                            <span className="text-lg font-light text-gray-400 mr-2">,</span>
                                            </p>
                                        ))}
                                        <span className="text-lg font-light text-gray-400">{post.type}</span>
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="sm:hidden flex flex-col items-end justify-end">
                            <p className="text-lg font-light">{post.date}</p>
                            {post.tags && (
                                <div className="flex flex-row items-center justify-end flex-wrap">
                                    {post.tags.map((tag, index) => (
                                        <p key={index} className="text-lg font-light text-gray-400">{tag}
                                        {/*
                                        {index !== (post.tags?.length ?? 0) - 1 && <span className="text-lg font-light text-gray-400 mr-2">,</span>}
                                        */}
                                        <span className="text-lg font-light text-gray-400 mr-2">,</span>
                                        </p>
                                    ))}
                                    <span className="text-lg font-light text-gray-400">{post.type}</span>
                                </div>
                            )}
                        </div>
                    </header>
                    {post.description && <p className="text-lg font-light mt-2">{post.description}</p>}
                    <div className={markdownStyles["markdown"]} dangerouslySetInnerHTML={{ __html: content }} />
                </article>
                <div className="hidden lg:flex w-full items-center justify-center mt-8">
                    <PostTableOfContents headings={headings} />
                </div>
            </div>
        </main>
    );
}

// TODO: generateMetadata and generateStaticParams
// https://github.com/vercel/next.js/blob/canary/examples/blog-starter/src/app/posts/%5Bslug%5D/page.tsx