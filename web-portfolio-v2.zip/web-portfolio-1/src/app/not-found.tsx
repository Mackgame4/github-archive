"use client";
import { Bomb } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function NotFound() {
    return (
        <div className="flex flex-col items-center justify-center w-full h-full pt-24">
            <Bomb className="w-24 h-24 text-primary mb-8" />
            <h1 className="text-4xl font-bold text-primary">404</h1>
            <p className="text-secundary">Page not found!</p>
            <Button variant="outline" className="mt-4" onClick={() => window.history.back()}>Go back</Button>
        </div>
    );
}