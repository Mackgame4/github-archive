"use client";
import Header from "@/components/sections/header";
import MouseMovement from "@/components/components/mouseMovement";
import Config from "@/lib/config";
import { motion, useScroll, useMotionValueEvent } from "framer-motion";
import { useRef, useState, useEffect } from "react";

export default function PageLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    const containerRef = useRef(null);
    const scrollTrigger = 0.05;
    const isMobile = () => {
        return window.innerWidth < 768; // Adjust this threshold as needed
    };
    const [scrollY, setScrollY] = useState(0);
    const [showScrollBar, setShowScrollBar] = useState(false);
    const { scrollYProgress } = useScroll({
        container: containerRef
    });

    useEffect(() => {
        const containerElement = containerRef.current as HTMLElement | null;
        const handleScroll = () => {
            if (containerElement) {
                const hasOverflow = containerElement.scrollHeight > containerElement.clientHeight;
                setShowScrollBar(hasOverflow && !isMobile());
            }
        };
        handleScroll(); // Check on mount
        containerElement?.addEventListener("scroll", handleScroll);
        window.addEventListener("resize", handleScroll);
        return () => {
            containerElement?.removeEventListener("scroll", handleScroll);
            window.removeEventListener("resize", handleScroll);
        };
    }, [containerRef]);

    if (Config.animatedScroll) {
        useMotionValueEvent(scrollYProgress, "change", (latest) => {
            setScrollY(latest);
        });
    }

    return (
        <div id="mainScreen" ref={containerRef} className="relative min-h-screen bg-gradient-to-t dark:from-neutral-900 dark:to-neutral-800 from-neutral-50 to-neutral-100 overflow-auto no-scrollbar scroll-smooth snap snap-y snap-mandatory">
            {Config.mouseGlow && (
                <div className="z-0 fixed top-0 left-0 w-full h-full">
                    <MouseMovement />
                </div>
            )}
            <header className="z-20 fixed top-0 left-0 w-full pointer-events-none">
                {Config.animatedScroll && showScrollBar && (
                    <motion.div className="z-20 fixed top-0 left-0 w-full h-1 bg-primary rounded-xl" style={{ scaleX: scrollYProgress }} />
                )}
                <Header scrollTrigger={scrollTrigger} showScrollBar={showScrollBar} scrollY={scrollY} />
            </header>
            <main className="z-10 relative w-full min-h-screen">
                <div className="flex flex-col items-center justify-start w-full h-screen">
                    {children}
                </div>
            </main>
        </div>
    );
}