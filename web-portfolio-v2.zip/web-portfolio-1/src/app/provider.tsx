"use client";
import { ThemeProvider } from "next-themes";
import Config from "@/lib/config";

export default function Provider({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return <ThemeProvider attribute="class" enableSystem={Config.defaultTheme === "system"} storageKey="theme" defaultTheme={Config.defaultTheme}>{children}</ThemeProvider>;
}