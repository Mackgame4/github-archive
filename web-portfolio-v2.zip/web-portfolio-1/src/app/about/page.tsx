export default function Home() {
  return (
    <>
      <h1 className="flex-1 text-6xl font-bold text-center text-primary dark:text-primary-light w-full h-full">
        About!
      </h1>
    </>
  );
}
