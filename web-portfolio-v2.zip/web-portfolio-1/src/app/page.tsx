import HeroSection from "@/components/sections/heroSection";
import PostCard from "@/components/components/postCard";
import FooterSection from "@/components/sections/footerSection";
import { getAllPostsByType } from "@/lib/actions/posts";

export default async function Home() {
  const posts = await getAllPostsByType("experience");

  return (
    <>
      <section className="snap-always snap-center w-full min-h-screen pt-48 sm:pt-60 pb-8 lg:px-40 px-8">
        <HeroSection />
      </section>
      {posts.map((post, index) => (
        <section key={index} className="snap-always snap-center w-full min-h-screen pt-48 sm:pt-40 pb-8 lg:px-40 px-8">
          <PostCard post={post} />
        </section>
      ))}
      <section className="snap-always snap-center w-full min-h-screen pt-48 sm:pt-60 pb-8 lg:px-40 px-8">
        <FooterSection />
      </section>
    </>
  );
} 
