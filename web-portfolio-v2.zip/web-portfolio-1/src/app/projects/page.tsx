import PostCard from "@/components/components/postCard";
import { getAllPostsByType } from "@/lib/actions/posts";

export default async function Posts() {
    const posts = await getAllPostsByType("project");

    return (
        <>
        {posts.map((post, index) => (
            <section key={index} className="snap-always snap-center w-full min-h-screen pt-48 sm:pt-40 pb-8 lg:px-40 px-8">
                <PostCard post={post} />
            </section>
        ))}
        </>
    );
}