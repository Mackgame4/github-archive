import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "@/styles/globals.css";
import { cn } from "@/lib/utils";
import Provider from "@/app/provider";
import Config from "@/lib/config";
import PageLayout from "@/app/page-layout";

const inter = Inter({ subsets: ["latin"] });

export const viewport: Viewport = {
  themeColor: Config.defaultTheme === "dark" ? "#000000" : "#ffffff",
  colorScheme: Config.defaultTheme === "dark" ? "dark" : "light",
};

export const metadata: Metadata = {
  title: Config.name + "'s | Personal Portfolio",
  description: Config.description,
  applicationName: Config.name + "'s | Personal Portfolio",
  keywords: Config.keywords,
  authors: Config.authors,
  creator: Config.authors[0].name,
  publisher: Config.authors[0].name,
  icons: {
    icon: [
      {
        media: '(prefers-color-scheme: light)',
        url: Config.favicon,
        href: Config.favicon,
        type: 'image/png',
      },
      {
        media: '(prefers-color-scheme: dark)',
        url: Config.favicon,
        href: Config.favicon,
        type: 'image/png',
      },
    ],
    shortcut: Config.favicon,
    apple: Config.favicon,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang={Config.defaultLang} suppressHydrationWarning className={Config.trueSSR && Config.defaultTheme === "dark" ? "dark" : ""}>
      <body className={cn("min-h-screen bg-background antialiased", inter.className)}>
        {!Config.trueSSR && (
          <Provider>
            <PageLayout>
              {children}
            </PageLayout>
          </Provider>
        )}
        {Config.trueSSR && (
          <PageLayout>
            {children}
          </PageLayout>
        )}
      </body>
    </html>
  );
}