"use client";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

export default function PostBackButton() {
    return (
        <Button variant="ghost" size="icon" className="rounded-full" aria-label="Back" onClick={() => window.history.back()}>
            <ArrowLeft className="w-6 h-6" />
        </Button>
    );
}