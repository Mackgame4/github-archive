import { TocItem } from "@/lib/markdownToHtml";
import { Table2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

export default function PostTableOfContents({ headings }: { headings: TocItem[] }) {
    return (
        <Popover>
            <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full" aria-label="Table of Contents">
                    <Table2 className="h-6 w-6" />
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-fit flex flex-col space-y-2 p-4 rounded-lg">
                <nav className="flex flex-col">
                    <ul className="list-none">
                        {headings.map((heading: any) => (
                            <li key={heading.slug}>
                                <a href={`#${heading.slug}`}>{heading.text}</a>
                                {heading.children && (
                                    <ul className="list-none ml-4">
                                        {heading.children.map((child: any) => (
                                            <li key={child.slug}>
                                                <a href={`#${child.slug}`}>{child.text}</a>
                                            </li>
                                        ))}
                                    </ul>
                                )}
                            </li>
                        ))}
                    </ul>
                </nav>
            </PopoverContent>
        </Popover>
    );
}