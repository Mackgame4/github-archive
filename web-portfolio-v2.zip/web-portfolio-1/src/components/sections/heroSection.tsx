import ThemeSwitch from "@/components/components/themeSwitch";
import { X, Square, Circle } from "lucide-react";
import { Button } from "@/components/ui/button";
import "@/styles/glareEffects.css";
import ScrollArrow from "@/components/components/scrollArrow";
import Config from "@/lib/config";

export default function HeroSection() {
    const { hero } = Config;
    // split the title into two parts (last word is a different color)
    const titleParts = hero.title.split(" ");
    const titleFirstPart = titleParts.slice(0, titleParts.length - 1).join(" ");
    const titleSecondPart = titleParts[titleParts.length - 1];
    return (
        <div className="relative p-2.5 rounded-3xl shadow-inner shadow-lg border border-[#3d3d3d] w-full h-full">
            <div className="flex flex-col w-full h-full rounded-2xl border border-neutral-400 backdrop-blur-xl backdrop-filter">
                <div className="relative max-h-20 flex flex-row items-center justify-between border-b border-neutral-500 w-full h-full rounded-t-2xl lg:px-12 px-8 p-4 windowGradient">
                    <div className="absolute top-0 h-[1px] mb-[-1px] w-full windowGlare" />
                    <div className="hidden dark:flex flex-row items-center justify-center gap-3">
                        <div className="bg-[#f46b5d] w-4 h-4 rounded-full shadow-[0_0_20px_2px_#f46b5d] border border-[rgba(16,16,16,0.1)] hover:shadow-none transition-shadow" />
                        <div className="bg-[#f9bd4e] w-4 h-4 rounded-full shadow-[0_0_20px_2px_#f9bd4e] border border-[rgba(16,16,16,0.1)] hover:shadow-none transition-shadow" />
                        <div className="bg-[#57c353] w-4 h-4 rounded-full shadow-[0_0_20px_2px_#57c353] border border-[rgba(16,16,16,0.1)] hover:shadow-none transition-shadow" />
                    </div>
                    <div className="flex dark:hidden flex-row items-center justify-center gap-3">
                        <Button variant="ghost" className="p-0.5 w-4 h-4 rounded-full">
                            <X className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" className="p-0.5 w-4 h-4 rounded-full">
                            <Square className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" className="p-0.5 w-4 h-4 rounded-full">
                            <Circle className="w-4 h-4" />
                        </Button>
                    </div>
                    <div className="-mr-4">
                        <ThemeSwitch />
                    </div>
                </div>
                <div className="relative flex-1 flex flex-col items-start justify-center w-full h-full p-12 sm:p-20 gap-20 sm:gap-4 overflow-auto no-scrollbar">
                    <div className="flex flex-col items-start justify-center gap-1">
                        <h1 className="dark:shadow-lg text-5xl sm:text-7xl font-bold">{titleFirstPart}
                            <span className="dark:text-transparent dark:bg-clip-text dark:bg-gradient-to-r dark:from-neutral-100 dark:to-neutral-600"> {titleSecondPart}</span>
                        </h1>
                        <h4 className="text-2xl font-light text-neutral-500">{hero.subtitle}</h4>
                    </div>
                    <div className="hidden xl:flex flex-col items-end justify-center gap-2 ml-auto">
                        <h3 className="text-xl font-bold">{hero.actionTitle}</h3>
                        <h4 className="text-lg font-light text-right dark:text-neutral-400 text-neutral-700">{hero.actionSubtitle}</h4>
                    </div>
                    <div className="absolute bottom-0 left-0 flex items-center justify-center w-full pb-4">
                        <ScrollArrow />
                    </div>
                </div>
            </div>
        </div>
    );
}