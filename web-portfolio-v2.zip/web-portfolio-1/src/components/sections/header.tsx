import NavMenu from "@/components/components/navMenu";
import Image from "next/image";
import Config from "@/lib/config";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { MoveUpRight, AtSign } from "lucide-react";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

function PopoverElements() {
    return (
        <>
            <Button variant="link">
                <Link href={Config.linkedinUrl} target="_blank" rel="noopener noreferrer" className="flex flex-row">LinkedIn<MoveUpRight className="ml-2 h-4 w-4" /></Link>
            </Button>
            <HoverCard>
                <HoverCardTrigger asChild>
                    <Button variant="link">
                        <Link href={Config.resumeUrl} target="_blank" rel="noopener noreferrer" className="flex flex-row">Resume<MoveUpRight className="ml-2 h-4 w-4" /></Link>
                    </Button>
                </HoverCardTrigger>
                <HoverCardContent>
                    <Image src="/assets/resume.png" priority={false} width={800} height={800} alt="Resume" />
                </HoverCardContent>
            </HoverCard>
        </>
    );
}

export default function Header({ scrollTrigger, showScrollBar, scrollY }: any) {
    return (
        <div className={`flex justify-center items-center w-full h-60 sm:h-16 ${showScrollBar && scrollY > scrollTrigger && scrollY < 1 ? "p-16" : "p-24"} transition-all duration-300`}>
            <div className="z-20 flex items-center space-x-3 mr-auto pointer-events-auto">
                <div className="hidden sm:flex items-center justify-center w-8 h-8">
                    <Image className="dark:flex hidden" src={`/dark/${Config.badgeLogo}`} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
                    <Image className="flex dark:hidden" src={`/light/${Config.badgeLogo}`} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
                </div>
                <div className="hidden lg:flex flex-col ml-4 text-sm font-light">
                    <span className="text-primary text-xl font-bold">{Config.name}</span>
                    <p className="text-secundary">{Config.badge}</p>
                </div>
            </div>
            <div className="z-10 absolute left-0 right-0 flex items-center justify-center pointer-events-auto">
                <div className="sm:hidden flex items-center justify-center w-8 h-8 absolute -top-16">
                    <Image className="dark:flex hidden" src={`/dark/${Config.badgeLogo}`} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
                    <Image className="flex dark:hidden" src={`/light/${Config.badgeLogo}`} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
                </div>
                <NavMenu />
            </div>
            <div className="z-20 flex ml-auto pointer-events-auto">
                <div className="hidden lg:flex items-center space-x-4">
                    <PopoverElements />
                </div>
                <Popover>
                    <PopoverTrigger asChild>
                        <Button variant="ghost" size="icon" className="flex lg:hidden sm:relative sm:top-0 sm:right-0 fixed top-4 right-4 rounded-full">
                            <AtSign className="h-6 w-6" />
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-fit flex flex-col space-y-2 p-4 rounded-lg">
                        <PopoverElements />
                    </PopoverContent>
                </Popover>
            </div>
        </div>
    );
}