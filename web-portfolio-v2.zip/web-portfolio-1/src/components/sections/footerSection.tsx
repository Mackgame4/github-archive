import { Button } from "@/components//ui/button";
import Image from "next/image";
import { Phone, Mail, MapPin, Github, Linkedin, Twitch, Twitter, Heart } from "lucide-react";
import Config from "@/lib/config";
import Link from "next/link";
import { getYear } from "@/lib/utils";

export default function FooterSection() {
    return (
        <div className="relative p-2.5 rounded-3xl shadow-inner shadow-lg border border-[#3d3d3d] w-full h-full">
            <div className="flex flex-col w-full h-full rounded-2xl border border-neutral-400 backdrop-blur-xl backdrop-filter">
                <div className="absolute top-[-1px] h-[1px] w-full windowGlare" />
                <div className="z-20 shadow-lg relative flex flex-col items-center justify-center w-full h-full border border-neutral-700 bg-neutral-800/30 rounded-2xl backdrop-blur-lg backdrop-filter">
                    <footer id="contact" className="flex flex-col items-center justify-center w-full h-full p-4 space-y-4 overflow-auto">
                        <div className="h-fit flex flex-col md:flex-row items-center justify-between w-full space-x-4 px-2">
                            <div className="flex flex-col sm:flex-row items-center justify-center space-x-4">
                                <Link href={`tel:${Config.phone}`} target="_blank" rel="noopener noreferrer" passHref>
                                    <Button variant="ghost" className="text-xs text-neutral-700 dark:text-neutral-500">
                                            <Phone className="w-4 h-4 mr-2" />
                                            {Config.phone}
                                    </Button>
                                </Link>
                                <Link href={`mailto:${Config.mail}`} target="_blank" rel="noopener noreferrer" passHref>
                                    <Button variant="ghost" className="text-xs text-neutral-700 dark:text-neutral-500">
                                        <Mail className="w-4 h-4 mr-2" />
                                        {Config.mail}
                                    </Button>
                                </Link>
                                <Link href={`https://www.google.com/maps/search/${Config.address}`} target="_blank" rel="noopener noreferrer" passHref>
                                    <Button variant="ghost" className="text-xs text-neutral-700 dark:text-neutral-500">
                                        <MapPin className="w-4 h-4 mr-2" />
                                        {Config.address}
                                    </Button>
                                </Link>
                            </div>
                            <div className="flex flex-row items-center justify-center space-x-4">
                                <Link href={Config.githubUrl} target="_blank" rel="noopener noreferrer" passHref>
                                    <Button variant="ghost" size="icon" className="text-xs text-neutral-700 dark:text-neutral-500 rounded-full">
                                        <Github className="w-4 h-4" />
                                    </Button>
                                </Link>
                                <Link href={Config.linkedinUrl} target="_blank" rel="noopener noreferrer" passHref>
                                    <Button variant="ghost" size="icon" className="text-xs text-neutral-700 dark:text-neutral-500 rounded-full">
                                        <Linkedin className="w-4 h-4" />
                                    </Button>
                                </Link>
                                <Link href={Config.twitterUrl} target="_blank" rel="noopener noreferrer" passHref>
                                    <Button variant="ghost" size="icon" className="text-xs text-neutral-700 dark:text-neutral-500 rounded-full">
                                        <Twitter className="w-4 h-4" />
                                    </Button>
                                </Link>
                            </div>
                        </div>
                        <div className="w-full mt-8 h-[1px] bg-neutral-500" />
                        <div className="flex-1 flex flex-row items-center justify-center w-full space-y-2">
                            <div className="w-full h-full flex flex-col items-center justify-center w-full space-y-8 p-4 bg-neutral-600/30 rounded-2xl backdrop-blur-lg backdrop-filter">
                                <div className="hidden sm:flex items-center space-x-3">
                                    <div className="flex items-center justify-center w-11 h-11">
                                        <Image className="dark:flex hidden" src={`/dark/${Config.badgeLogo}`} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
                                        <Image className="flex dark:hidden" src={`/light/${Config.badgeLogo}`} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
                                    </div>
                                    <div className="flex flex-col ml-4 text-sm font-light">
                                        <span className="text-primary text-xl sm:text-2xl font-bold">{Config.name}</span>
                                        <p className="text-secundary sm:text-lg">{Config.badge}</p>
                                    </div>
                                </div>
                                <span className="hidden min-[320px]:flex sm:text-xl text-neutral-100 font-bold">Liked what you saw? Let's work together!</span>
                                <span className="text-lg text-neutral-400">Contact me through the information above & follow me on social media:</span>
                                <div className="flex flex-row items-center justify-center space-x-4">
                                    <Link href={Config.githubUrl} target="_blank" rel="noopener noreferrer" passHref>
                                        <Button variant="ghost" size="icon" className="text-xs text-neutral-700 dark:text-neutral-500 rounded-full">
                                            <Github className="w-4 h-4" />
                                        </Button>
                                    </Link>
                                    <Link href={Config.linkedinUrl} target="_blank" rel="noopener noreferrer" passHref>
                                        <Button variant="ghost" size="icon" className="text-xs text-neutral-700 dark:text-neutral-500 rounded-full">
                                            <Linkedin className="w-4 h-4" />
                                        </Button>
                                    </Link>
                                    <Link href={Config.twitterUrl} target="_blank" rel="noopener noreferrer" passHref>
                                        <Button variant="ghost" size="icon" className="text-xs text-neutral-700 dark:text-neutral-500 rounded-full">
                                            <Twitter className="w-4 h-4" />
                                        </Button>
                                    </Link>
                                </div>
                                <span className="hidden sm:flex flex-row gap-1.5 text-sm text-neutral-200">Made with <Heart className="w-4 h-4 mt-0.5" /> by {Config.name}</span>
                            </div>
                            <div className="w-full h-full hidden md:flex flex-col sm:flex-row items-center justify-center w-full space-y-2">
                                <div className="flex flex-col items-center justify-center w-full space-y-2">
                                    <h2 className="text-xl font-bold text-neutral-100">Pages</h2>
                                    <Link href="/" passHref>
                                        <Button variant="link" className="text-sm text-neutral-200">Home</Button>
                                    </Link>
                                    <Link href="/projects" passHref>
                                        <Button variant="link" className="text-sm text-neutral-200">Projects</Button>
                                    </Link>
                                    <Link href="/about" passHref>
                                        <Button variant="link" className="text-sm text-neutral-200">About</Button>
                                    </Link>
                                    <Link href="/#contact" passHref>
                                        <Button variant="link" className="text-sm text-neutral-200">Contact</Button>
                                    </Link>
                                </div>
                                <div className="flex flex-col items-center justify-center w-full space-y-2">
                                    <h2 className="text-xl font-bold text-neutral-100">Resources</h2>
                                    <Link href="/posts" passHref>
                                        <Button variant="link" className="text-sm text-neutral-200">Posts</Button>
                                    </Link>
                                    <Link href={Config.resumeUrl} target="_blank" rel="noopener noreferrer" passHref>
                                        <Button variant="link" className="text-sm text-neutral-200">Resume</Button>
                                    </Link>
                                    <Link href={Config.githubUrl} target="_blank" rel="noopener noreferrer" passHref>
                                        <Button variant="link" className="text-sm text-neutral-200">GitHub</Button>
                                    </Link>
                                    <Link href={Config.linkedinUrl} target="_blank" rel="noopener noreferrer" passHref>
                                        <Button variant="link" className="text-sm text-neutral-200">LinkedIn</Button>
                                    </Link>
                                </div>
                            </div> 
                        </div>
                        <div className="w-full h-[1px] bg-neutral-500" />
                        <div className="h-8 flex flex-row items-center justify-between w-full space-x-4 px-2">
                            <span className="text-xs text-neutral-700 dark:text-neutral-500">&copy; {getYear()} {Config.name}, All Rights Reserved.</span>
                            <div className="hidden sm:flex flex-row items-center justify-center space-x-4">
                                <Button variant="outline" className="text-xs text-neutral-700 dark:text-neutral-500">Terms of Service</Button>
                                <Button variant="outline" className="text-xs text-neutral-700 dark:text-neutral-500">Privacy Policy</Button>
                                <Button variant="outline" className="text-xs text-neutral-700 dark:text-neutral-500">Cookie Policy</Button>
                            </div>
                        </div>
                    </footer>
                </div>
            </div>
        </div>
    );
}