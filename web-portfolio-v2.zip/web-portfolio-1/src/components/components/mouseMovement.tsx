"use client";
import { useRef } from "react";
import { motion } from "framer-motion";
import { useFollowPointer } from "@/lib/mouseMovement";

export default function MouseMovement() {
    const ref = useRef(null);
    const { x, y } = useFollowPointer(ref);

    return (
        <div className="z-0 flex items-center justify-center w-screen h-screen overflow-hidden pointer-events-none">
            <motion.div ref={ref} className="absolute top-0 left-[50%] w-[50px] h-[50px] rounded-full pointer-events-none bg-gradient-to-br from-neutral-400 to-neutral-500 mix-blend-screen filter blur-[50px] opacity-60" style={{ x, y }} />
        </div>
    );
}