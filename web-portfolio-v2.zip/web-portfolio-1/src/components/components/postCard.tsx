"use client";
import "@/styles/glareEffects.css";
import { PostType } from "@/lib/types";
import serverRedirect from "@/lib/actions/serverRedirect";
import Image from "next/image";
import { MoveRight } from "lucide-react";

export default function PostCard({ post }: { post: PostType }) {
    const accentColor = post.accentColor ? post.accentColor : "#2b2b2b";

    function handlePostClick() {
        serverRedirect(`/posts/${post.slug}`).then(() => {
            // TODO: fix this
            // lazy fix for scroll to top on post click
            const mainScreen = document.getElementById("mainScreen");
            if (mainScreen) {
                mainScreen.scrollTo({ top: 0, behavior: "smooth" });
            }
        });
    }

    return (
        <div className="relative p-2.5 rounded-3xl shadow-inner shadow-lg border border-[#3d3d3d] w-full h-full bg-gradient-to-tr dark:from-[#252525] dark:to-neutral-600 from-neutral-100 to-neutral-300/50">
            <div className="group flex flex-col items-center justify-center w-full h-full cursor-pointer" onClick={() => handlePostClick()}>
                <div className="opacity-100 group-hover:opacity-0 transition-opacity duration-700 absolute top-0 h-[1px] mb-[-1px] w-full windowGlare" />
                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-700 absolute top-0 h-[1.5px] mb-[-1px] w-full" style={{ background: `linear-gradient(to right, transparent 10%, ${accentColor} 50%, transparent 90%)` }} />
                <div className="z-10 group-hover:shadow-inner group-hover:shadow-lg opacity-0 group-hover:opacity-100 absolute m-2.5 top-[-1px] left-[-1px] right-[-1px] h-full rounded-t-2xl pointer-events-none transition-opacity duration-700" style={{ background: `linear-gradient(178deg, transparent 0%, ${accentColor} 3%, transparent 75%, transparent 100%)` }} />
                <div className="z-20 shadow-lg group relative flex flex-col items-center justify-center w-full h-full border border-neutral-700 bg-neutral-800/30 rounded-2xl backdrop-blur-lg backdrop-filter">
                    <div className="flex flex-col items-center justify-center w-full h-full gap-4">
                        <div className="relative w-full flex flex-row items-center justify-center p-8 overflow-hidden">
                            <div className="flex flex-col items-start justify-start w-full h-full">
                                <h1 className="text-3xl sm:text-4xl font-bold text-left">{post.title}</h1>
                                <h2 className="text-lg font-light text-left">{post.subtitle} - {post.description}</h2>
                            </div>
                            <div className="flex flex-col items-center justify-center -mt-6 w-10">
                                <MoveRight className="w-8 h-8" />
                            </div>
                        </div>
                        <div className="sm:flex hidden w-full relative rounded-xl overflow-hidden mt-auto px-12">
                            <Image src={post.coverImage ?? ''} alt={post.title} width={1920} height={128} style={{ width: "100%", height: "100%", objectFit: "contain" }} className="rounded-xl" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}