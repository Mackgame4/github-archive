"use client";
import { Sun, Moon, SunMoon } from "lucide-react";
import { useState, useEffect } from "react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";

export default function ThemeSwitch() {
    const [mounted, setMounted] = useState(false)
    const {setTheme, resolvedTheme} = useTheme()

    useEffect(() =>  setMounted(true), [])

    if (!mounted) {
        return <Button variant="ghost" size="icon" className="rounded-full">
        <SunMoon className="h-4 w-4" />
    </Button>;
    }

    if (resolvedTheme === 'dark') {
        return <Button variant="ghost" size="icon" className="rounded-full" onClick={() => setTheme('light')}>
        <Sun className="h-4 w-4" />
    </Button>;
    }

    if (resolvedTheme === 'light') {
        return <Button variant="ghost" size="icon" className="rounded-full" onClick={() => setTheme('dark')}>
            <Moon className="h-4 w-4" />
        </Button>;
    }
}