"use client";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import Config from "@/lib/config";
import { Button } from "@/components/ui/button";
import serverRedirect from "@/lib/actions/serverRedirect";
import { usePathname } from "next/navigation";

export default function NavMenu() {
    const tabs = Config.tabs;
    const pathname = usePathname();
    const [activeTab, setActiveTab] = useState(() => {
        const index = tabs.findIndex((tab) => tab.href === pathname);
        return index !== -1 ? index : 0;
    });

    function handleTabClick(index: number) {
        //setActiveTab(index); // Making it more responsive, only changeing tab after loading/rendering the new page
        serverRedirect(tabs[index].href);
    }

    useEffect(() => {
        const index = tabs.findIndex((tab) => tab.href === pathname);
        if (index !== -1) {
            setActiveTab(index);
        }
    }, [pathname]);

    return (
        <div className="bg-[rgba(242,242,242,0.05)] border dark:border-[rgba(242,242,242,0.1)] border-gray-200 rounded-full flex justify-between items-center w-fit h-fit p-1.5 relative shadow-[0_10px_25px_rgba(0,0,0,0.15)] select-none backdrop-blur-xl backdrop-filter">
        {tabs.map((tab, index) => (
            <Button key={index} variant="ghost" onClick={() => handleTabClick(index)} className="hover:bg-transparent relative rounded-full px-3 py-2 text-sm font-medium dark:text-white text-black transition focus-visible:outline-2" style={{ WebkitTapHighlightColor: "transparent" }}>
            {activeTab === index && (
                <motion.span layoutId="bubble" className="flex justify-center items-center absolute inset-0 -z-10 rounded-full dark:bg-[rgba(242,242,242,0.05)] bg-[rgba(0,0,0,0.05)]" transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}>
                    <motion.span layoutId="pill" className="absolute -top-2.5 dark:bg-white bg-black rounded-[2px] w-[24px] h-[4px] shadow-[0_2px_25px_2px_white]" transition={{ type: "spring", bounce: 0.2, duration: 0.6 }} />
                </motion.span>
            )}
            {tab.label}
            </Button>
        ))}
        </div>
    );
}