"use client";
import { motion } from "framer-motion";
import { Mouse } from "lucide-react";

export default function ScrollArrow() {
    return (
        <motion.div
            initial={{ y: 0, opacity: 1 }}
            animate={{ y: [0, -8, 0], opacity: [1, 0.5, 1] }}
            transition={{ 
                duration: 2, 
                ease: "easeInOut", 
                times: [0, 0.5, 1], 
                repeat: Infinity, 
                repeatDelay: 0 
            }}
            className="z-50 flex flex-col items-center justify-center w-12 h-12 rounded-full shadow-lg"
        >
            <Mouse className="w-6 h-6 dark:text-neutral-300 text-neutral-700" />
        </motion.div>
    );
}