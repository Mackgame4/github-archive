import { remark } from 'remark';
import remarkHtml from 'remark-html';
import remarkToc from 'remark-toc';
import remarkSlug from 'remark-slug';
import remarkParse from 'remark-parse';

export async function markdownToHtml(markdown: string) {
    const result = await remark()
        .use(remarkSlug as any)
        .use(remarkParse)
        .use(remarkHtml, { sanitize: false })
        .process(markdown);
    return result.toString();
}

export type TocItem = {
    slug: string;
    text: string;
    level: number;
    children?: TocItem[];
};

export async function markdownToToc(markdown: string) {
    const tocItems: TocItem[] = [];
    const stack: TocItem[] = [];

    await remark()
        .use(remarkSlug as any)
        .use(remarkParse)
        .use(remarkHtml)
        .use(remarkToc, { tight: true, ordered: true, prefix: 'user-content-' })
        .use(() => (tree) => {
            (tree as any).children.forEach((node: any) => {
                if (node.type === 'heading' && node.depth <= 6) {
                    const text = node.children.map((child: any) => child.value).join('');
                    const rawSlug = node.data.id;
                    const slug = `user-content-${rawSlug}`;
                    const tocItem: TocItem = { text, level: node.depth, slug, children: [] };
                    while (stack.length > 0 && stack[stack.length - 1].level >= node.depth) {
                        stack.pop();
                    }
                    if (stack.length === 0) {
                        tocItems.push(tocItem);
                    } else {
                        const parent = stack[stack.length - 1];
                        parent.children = parent.children || [];
                        parent.children.push(tocItem);
                    }
                    stack.push(tocItem);
                }
            });
        })
        .process(markdown);
    return tocItems;
}