export type PostType = {
    slug: string;
    title: string;
    subtitle?: string;
    description?: string;
    type: "experience" | "project" | "blog" | "other";
    date?: string;
    coverImage?: string;
    accentColor?: string;
    tags?: string[];
    link?: string;
    author: Author;
    ogImage?: string;
    content: string;
};

export type Author = {
    name: string;
    avatar: string;
    url?: string;
};