"use server";
import { redirect } from "next/navigation";

export default async function serverRedirect(path: string) {
    redirect(path);
}