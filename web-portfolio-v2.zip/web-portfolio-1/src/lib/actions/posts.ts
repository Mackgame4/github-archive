"use server";
import { PostType } from "@/lib/types";
import fs from "fs";
import matter from "gray-matter";
import { join } from "path";

const postsDirectory = join(process.cwd(), "_posts");

export async function getPostSlugs(): Promise<string[]> {
    try {
        return fs.readdirSync(postsDirectory).filter((file) => file.endsWith(".md"));
    }
    catch (error) {
        return [];
    }
}

export async function getPostBySlug(slug: string): Promise<PostType | null> {
    try {
        const realSlug = slug.replace(/\.md$/, "");
        const fullPath = join(postsDirectory, `${realSlug}.md`);
        const fileContents = fs.readFileSync(fullPath, "utf8");
        const { data, content } = matter(fileContents);
        return { ...data, slug: realSlug, content } as PostType;
    }
    catch (error) {
        return null;
    }
}

export async function getAllPosts(): Promise<PostType[]> {
    const slugs = await getPostSlugs();
    const posts = await Promise.all(slugs.map((slug) => getPostBySlug(slug)));
    return posts.filter((post) => post !== null).sort((a, b) => (a?.date && b?.date) ? (a.date > b.date ? -1 : 1) : 0) as PostType[];
}

export async function getAllPostsByTag(tag: string): Promise<PostType[]> {
    const posts = await getAllPosts();
    return posts.filter((post) => post.tags?.includes(tag));
}

type PostTypeValues = PostType['type'];
export async function getAllPostsByType(type: PostTypeValues): Promise<PostType[]> {
    const posts = await getAllPosts();
    return posts.filter((post) => post.type === type);
}