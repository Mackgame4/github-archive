import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { useTheme } from "next-themes";

export function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs))
}

export function getTheme() {
    const theme = useTheme().theme;
    return theme;
}

export function getYear() {
    return new Date().getFullYear();
}