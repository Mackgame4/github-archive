const Config = {
    trueSSR: false, // With this enabled we cant use the theme provider (only the predefined theme)
    defaultTheme: "dark", // "light" or "dark" or "system"
    mouseGlow: true, // enables the mouse glow effect
    animatedScroll: true, // enables the animated scroll effect
    name: "CodeWithFab",
    badge: "Software Engenieer",
    description: "Personal Portfolio",
    badgeLogo: "logo_badge.png",
    favicon: "/favicon/logo_square.png",
    keywords: ['Next.js', 'React', 'JavaScript'],
    authors: [{ name: 'Mackgame4', url: 'https://mackgame4.github.io/' }],
    defaultLang: "en",

    phone: "+351 123 456 789",
    mail: "mail@mail.com",
    address: "Braga, Portugal",

    githubUrl: "",
    linkedinUrl: "https://www.linkedin.com/",
    twitterUrl: "",
    twitchUrl: "",
    resumeUrl: "https://github.com/Mackgame4/mackgame4", // or use a local file "/resume.pdf"

    tabs: [
        { label: "Home", href: "/" },
        { label: "Projects", href: "/projects" },
        { label: "About", href: "/about" }
    ],

    hero: {
        title: "Building the Future Through Code",
        subtitle: "Your Vision, Our Code: Let's Create Together.",
        actionTitle: "Hi, I'm Fábio!",
        actionSubtitle: "I'm a Computer Science student at the University of Minho in Portugal. I'm passionate about technology and I'm always looking for new challenges.",
    },
};

export default Config;