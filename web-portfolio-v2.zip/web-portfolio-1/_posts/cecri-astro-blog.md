---
type: "experience"
title: "Cecri Astro Blog"
subtitle: "Freelance"
description: "A blog website for a client who wanted to share their events and search cases. The website is built with Astro.js, a static site generator, with islands, and TailwindCSS. The client can easily update the content using a CMS that supports Markdown and Markdoc files."
coverImage: "/assets/blog/astro-blog/homepage.png"
date: "2023-03"
tags: ["freelance", "web", "blog", "astrojs", "CMS", "TailwindCSS", "Markdown"]
accentColor: "#32a852"
link: "https://cecri-blog.vercel.app/"
ogImage: "/assets/blog/astro-blog/homepage.png"
---