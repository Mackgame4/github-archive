---
type: "experience"
title: "Dentist Dashboard & POS"
subtitle: "Freelance"
description: "A dashboard and POS system for a dentist clinic. The system is built with Next.js, React, TailwindCSS, TypeScript and MongoDB. The system includes a dashboard for the dentist to manage their patients, appointments, and treatments. The POS system is used to manage the clinic's inventory and sales."
coverImage: "/assets/blog/dentist-dashboard/homepage.png"
date: "2024-06"
tags: ["nextjs", "react", "tailwindcss", "typescript", "mongodb", "dashboard"]
accentColor: "#b0b0b0"
ogImage: "/assets/blog/dentist-dashboard/homepage.png"
---

# Context

A dentist clinic needed a system to manage their patients, appointments, treatments, inventory, and sales. The system should be easy to use and accessible from any device.

# The Problem

The dentist clinic was using paper-based systems to manage their patients, appointments, treatments, inventory, and sales. This was time-consuming and error-prone. The clinic needed a digital system to manage their operations more efficiently.

Because the system need to always work even if the internet connection is down, the system should be able to work offline and sync data when the internet connection is back.

One way of achieving this is by using a PWA (Progressive Web App) or using a physical server machine connected directly via LAN or WI-FI direct to the main system. The server machine will act as a local server that will store the data and sync it with the main database.

# Solution

I built a dashboard and POS system for the dentist clinic. The system is built with Next.js, React, TailwindCSS, TypeScript, and MongoDB. The system includes a dashboard for the dentist to manage their patients, appointments, and treatments. The POS system is used to manage the clinic's inventory and sales.

# Features

- Dashboard for managing patients, appointments, and treatments
- POS system for managing inventory and sales
- Responsive design for mobile, tablet, and desktop
- Easy to use and accessible from any device
- Built with Next.js, React, TailwindCSS, TypeScript, and MongoDB