"use client";
import { getThemeColor } from "@/lib/utils";
import { MoveLeft, Table2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import MdxProvider from "@/components/components/mdx-provider";
import { PostType } from "@/lib/types";
import { useState, useEffect, useRef } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import Config from "@/lib/config";

export default function PostContent({ post }: { post: PostType }) {
    const accentColor = post?.accentColor ? post.accentColor : getThemeColor();
    const mdxContent = useRef<HTMLDivElement>(null);
    const [toc, setToc] = useState<{ title: string; level: number; }[]>([]);

    function mdxToc() {
        if (mdxContent.current) {
            const headings = mdxContent.current.querySelectorAll('h1, h2, h3, h4, h5, h6');
            const toc = Array.from(headings).map((heading: Element) => {
                const element = heading as HTMLElement;
                return {
                    title: element.innerText,
                    level: parseInt(element.tagName.replace('H', ''))
                };
            });
            return toc;
        }
        return [];
    }

    useEffect(() => setToc(mdxToc()), [post]);

    return (
        <div className="px-6 pt-8 pb-24 sm:px-24 sm:pt-48 sm:pb-8 w-full min-w-0">
            <div className="fixed top-0 h-[1.5px] mb-[-1px] w-full" style={{ background: `linear-gradient(to right, transparent 10%, ${accentColor} 50%, transparent 90%)` }} />
            <div className="flex flex-row items-start justify-between w-full h-full gap-6 sm:gap-7 min-w-0">
                <div className="flex">
                    <Button variant="ghost" size="icon" className="hidden sm:flex rounded-full mt-0 sm:mt-4 ml-auto" aria-label="Back" onClick={() => window.history.back()}>
                        <MoveLeft className="w-6 h-6" />
                    </Button>
                </div>
                <div className="w-full max-w-4xl min-w-0 overflow-auto">
                    <div className="flex flex-row items-center w-full mb-4">
                        <Button variant="ghost" size="icon" className="sm:hidden flex rounded-full" aria-label="Back" onClick={() => window.history.back()}>
                            <MoveLeft className="w-6 h-6" />
                        </Button>
                        <Popover>
                            <PopoverTrigger asChild>
                                <Button variant="ghost" size="icon" className="sm:hidden flex rounded-full ml-auto">
                                    <Table2 className="w-6 h-6" />
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent>
                                <div className="flex flex-col w-full">
                                    {toc.map((item, index) => (
                                        <a key={index} className={`text-sm ml-${item.level * 2} ${index != 0 ? 'mt-2' : ''}`}>{item.title}</a>
                                    ))}
                                </div>
                            </PopoverContent>
                        </Popover>
                    </div>
                    <div className="w-full">
                        <Image src={post.image as string} width={1920} height={980} alt={post.title} style={{ width: '100%', height: 'auto', objectFit: 'cover' }} />
                    </div>
                    <div className="flex flex-col sm:flex-row items-start mt-1.5">
                        <div className="flex flex-col items-start">
                            <h1 className="text-4xl font-bold">{post.title}</h1>
                            <h2 className="text-xl text-neutral-500">{post.subtitle}</h2>
                        </div>
                        <div className="flex flex-col ml-0 items-start sm:items-end sm:ml-auto mt-2 sm:mt-0">
                            <a href={post.author?.url} target="_blank" rel="noopener noreferrer" className="text-neutral-500">by {post.author ? post.author.name : Config.profile.name}</a>
                            <p className="text-neutral-500 mt-1">{post.date}</p>
                        </div>
                    </div>
                    <div ref={mdxContent} className="mt-8">
                        <p className="text-neutral-500">{post.description}</p>
                        <div className="flex flex-row items-center my-2 overflow-auto max-w-full no-scrollbar">
                            <span className="text-xs text-neutral-500 bg-neutral-100 px-2 py-1 rounded-full mr-1.5">{post.type}</span>
                            {post.tags?.map((tag, index) => (
                                <span key={index} className="text-xs text-neutral-500 bg-neutral-100 px-2 py-1 rounded-full mr-1.5">{tag}</span>
                            ))}
                        </div>
                        <div className="mt-8">
                            <MdxProvider source={post.content} />
                        </div>
                    </div>
                </div>
                <div className="flex">
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button variant="ghost" size="icon" className="hidden sm:flex rounded-full mt-0 sm:mt-4">
                                <Table2 className="w-6 h-6" />
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent>
                            <div className="flex flex-col w-full">
                                {toc.map((item, index) => (
                                    <a key={index} className={`text-sm ml-${item.level * 2} ${index != 0 ? 'mt-2' : ''}`}>{item.title}</a>
                                ))}
                            </div>
                        </PopoverContent>
                    </Popover>
                </div>
            </div>
        </div>
    );
}