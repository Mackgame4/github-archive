"use client";
import "@/styles/glare.css";
import { PostType } from "@/lib/types";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { MoveRight } from "lucide-react";
import { getThemeColor } from "@/lib/utils";

function PostContent({ post }: { post: PostType }) {
    return (
        <div className="group relative flex flex-col w-full h-fit">
            <div className="flex flex-row w-full h-fit max-h-48 mb-8 px-6 py-4">
                <div className="flex flex-col">
                    <h1 className="text-2xl font-bold">{post.title}</h1>
                    <h2 className="text-lg text-neutral-500">{post.subtitle}</h2>
                </div>
                <div className="ml-auto px-4 py-3 group-hover:px-2 transition-all duration-700">
                    <MoveRight className="w-8 h-8" />
                </div>
            </div>
            <div className="flex w-full h-fit items-center justify-center px-2 sm:px-6">
                <div className="h-full">
                    <Image src={post.image as string} width={1920} height={980} alt={post.title} style={{ width: 'auto', height: '100%', objectFit: 'contain' }} />
                </div>
            </div>
            {/*<div className="hidden xl:flex flex-col w-full h-fit mt-auto px-6 pb-4">
                <p className="font-bold text-neutral-500">{post.description}</p>
                <p className="text-neutral-500">{post.author?.name} - {post.date}</p>
            </div>*/}
        </div>
    );
}

export default function PostCard({ post }: { post: PostType }) {
    let accentColor = post?.accentColor ? post.accentColor : getThemeColor();
    const router = useRouter();

    // if accent color is not hex color, use default accent color
    if (!accentColor.match(/^#[0-9A-F]{6}$/i)) {
        accentColor = getThemeColor();
    }

    function handlePostClick() {
        router.push(`/posts/${post.slug}`);
    }

    return (
        <div className="group relative rounded-2xl shadow-inner shadow-lg border border-neutral-600 w-full h-full outline-offset-[-1px] cursor-pointer" onClick={handlePostClick}>
            <div className="group-hover:opacity-70 opacity-0 absolute top-0 h-[1px] mb-[-1px] w-full windowGlare" style={{ background: `linear-gradient(to right, transparent 10%, ${accentColor} 50%, transparent 90%)` }} />
            <div className="group-hover:shadow-inner group-hover:shadow-lg opacity-0 group-hover:opacity-50 absolute top-[-1px] left-[-1px] right-[-1px] h-full rounded-t-2xl pointer-events-none transition-opacity duration-700" style={{ background: `linear-gradient(to bottom, ${accentColor} 0%, transparent 75%, transparent 100%)` }} />
            <PostContent post={post} />
        </div>
    );
}