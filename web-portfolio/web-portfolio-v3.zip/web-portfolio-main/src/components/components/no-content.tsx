export default function NoContent() {
    return (
        <div className="flex flex-col items-center justify-center h-screen">
            <h1 className="text-4xl font-bold text-neutral-500">No content available.</h1>
        </div>
    );
}