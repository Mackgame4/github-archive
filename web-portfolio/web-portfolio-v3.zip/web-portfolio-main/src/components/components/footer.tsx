import Link from 'next/link';
import Config from '@/lib/config';
import { Copyright, Mail, MapPin, Github, Linkedin, Twitter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getYear } from '@/lib/utils';
import Image from 'next/image';

export default function Footer() {
    let profileLinkedin = Config.profile.socials.find(social => social.name === "LinkedIn");
    let profileGithub = Config.profile.socials.find(social => social.name === "GitHub");
    let profileTwitter = Config.profile.socials.find(social => social.name === "Twitter");
    return (
        <footer className="relative w-full">
            <div className="w-full h-[1px] bg-neutral-800" />
            <div className="grid grid-cols-1 gap-8 w-full px-12 py-12 md:px-36 md:py-20 md:grid-cols-2">
                <div className="flex flex-col items-start justify-start">
                    <div className="w-10 h-fit mb-4">
                        <Image className="dark:flex hidden" src={Config.assets.badgeLogo.dark} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
                        <Image className="flex dark:hidden" src={Config.assets.badgeLogo.light} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
                    </div>
                    <div className="flex flex-col items-start justify-start space-y-2 mt-auto">
                        <span className="flex flex-row items-center justify-center gap-1.5">
                            <Copyright className="w-4 h-4" /> <span>{getYear()} {Config.profile.name}. All Rights Reserved.</span>
                        </span>
                        <span className="group flex flex-row items-center justify-center gap-1.5 text-neutral-600">
                            Made with <span className="text-red-500 group-hover:text-primary transition-colors">❤</span> by {Config.profile.name}.
                        </span>
                    </div>
                </div>
                <div className="flex flex-col items-start w-fit justify-start md:ml-auto gap-8">
                    <div className="flex flex-col lg:flex-row items-start justify-start lg:space-x-8 space-y-4 lg:space-y-0">
                        <div className="flex flex-col items-start justify-start space-y-2">
                            <span className="text-xs font-bold text-neutral-500 tracking-widest">PAGES</span>
                            {Config.tabs.map(tab => (
                                <Link key={tab.label} href={tab.href} passHref>
                                    <Button variant="link" className="p-0 text-sm text-neutral-200">
                                        {tab.label}
                                    </Button>
                                </Link>
                            ))}
                        </div>
                        <div className="flex flex-col items-start justify-start space-y-2">
                            <span className="text-xs font-bold text-neutral-500 tracking-widest">LEGAL</span>
                            <Link href="/terms" passHref>
                                <Button variant="link" className="p-0 text-sm text-neutral-200">
                                    Terms of Service
                                </Button>
                            </Link>
                            <Link href="/cookies" passHref>
                                <Button variant="link" className="p-0 text-sm text-neutral-200">
                                    Cookies Policy
                                </Button>
                            </Link>
                        </div>
                        <div className="flex flex-col items-start justify-start space-y-2">
                            <span className="text-xs font-bold text-neutral-500 tracking-widest">CONTACT</span>
                            <div className="flex flex-row items-center justify-start gap-2">
                                <Mail className="w-4 h-4" />
                                <span>{Config.profile.email}</span>
                            </div>
                            <div className="flex flex-row items-center justify-start gap-2">
                                <MapPin className="w-4 h-4" />
                                <span>{Config.profile.address}</span>
                            </div>
                            <div className="flex flex-row items-center justify-start gap-2">
                                <Github className="w-4 h-4" />
                                <span>{profileGithub?.handle}</span>
                            </div>
                            <div className="flex flex-row items-center justify-start gap-2">
                                <Linkedin className="w-4 h-4" />
                                <span>{profileLinkedin?.handle}</span>
                            </div>
                            <div className="flex flex-row items-center justify-start gap-2">
                                <Twitter className="w-4 h-4" />
                                <span>{profileTwitter?.handle}</span>
                            </div>
                        </div>
                    </div>
                    <span className="flex flex-row items-center h-justify-center gap-1.5 text-neutral-600 mt-auto">
                        Last Updated by {Config.profile.name} on {new Date().toLocaleDateString()}.
                    </span>
                </div>
            </div>
        </footer>
    );
}