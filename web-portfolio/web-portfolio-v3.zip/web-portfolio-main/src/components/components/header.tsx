"use client";
import NavMenu from "@/components/components/nav-menu";
import Image from "next/image";
import Config from "@/lib/config";
import AtButton, { PopoverElements } from "@/components/components/atbutton";
import { cn } from "@/lib/utils";
import { useScroll } from "framer-motion";
import { useState, useEffect } from "react";

export default function Header() {
    const { scrollYProgress } = useScroll();
    const [scrollY, setScrollY] = useState(0);
    useEffect(() => {
        const scrolledPage = scrollYProgress.on("change", (latest) => {
            setScrollY(latest);
        });
        return () => {
            scrolledPage();
        };
    }, [scrollYProgress]);
    return (
        <div className={cn("z-50 fixed top-0 left-0 flex justify-center items-center w-full px-24 py-20 pointer-events-none transition-all duration-300", scrollY > 0.025 && scrollY < 1 ? "px-14 py-12" : "")}>
            <div className="z-20 flex items-center space-x-3 mr-auto pointer-events-auto">
                <div className="hidden sm:flex items-center justify-center w-8 h-8">
                    <Image className="dark:flex hidden" src={Config.assets.badgeLogo.dark} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
                    <Image className="flex dark:hidden" src={Config.assets.badgeLogo.light} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
                </div>
                <div className="hidden lg:flex flex-col ml-4 text-sm font-light">
                    <span className="text-primary text-xl font-bold">{Config.profile.name}</span>
                    <p className="text-secundary">{Config.profile.badge}</p>
                </div>
            </div>
            <div className="fixed bottom-5 z-10 sm:absolute sm:left-0 sm:right-0 sm:bottom-0 sm:top-0 flex items-center justify-center">
                <div className="pointer-events-auto">
                    <NavMenu />
                </div>
            </div>
            <div className="z-20 ml-auto pointer-events-auto">
                <div className="hidden lg:flex items-center space-x-4">
                    <PopoverElements />
                </div>
                <div className="sm:flex lg:hidden hidden">
                    <AtButton className="rounded-full" />
                </div>
            </div>
        </div>
    );
}