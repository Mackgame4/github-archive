"use client";
import { Button } from "@/components/ui/button";
import { toggleAudio } from "@/lib/utils";
import { Volume2, VolumeX } from "lucide-react";
import { useState, useEffect } from "react";
import { playAudio } from "@/lib/utils";

export default function ToggleAudio() {
    const [audioEnabled, setAudioEnabled] = useState(false);

    function handleClick() {
        setAudioEnabled(toggleAudio());
        playAudio("/assets/audio/soap-pop.wav");
    };

    useEffect(() => {
        setAudioEnabled(toggleAudio());
    }, []);

    return (
        <>
            <Button onClick={() => handleClick()} variant="ghost" size="icon" className="rounded-full">
                {audioEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </Button>
        </>
    );
}