"use client";
import ThemeSwitch from "@/components/components/theme-switch";
import ToggleAudio from "@/components/components/toggle-audio";
import { QrCode, X, Square, Circle } from "lucide-react";
import { Button } from "@/components/ui/button";
import "@/styles/glare.css";
import Config from "@/lib/config";
import ScrollArrow from "@/components/components/scroll-arrow";
import { playAudio } from "@/lib/utils";
import { useRouter } from "next/navigation";
import ContentCard from "@/components/components/content-card";

function TopBar() {
    return (
        <div className="relative h-16 flex flex-row items-center justify-between border-b border-neutral-500 w-full h-full rounded-t-2xl lg:px-12 px-8 p-4 windowGradient">
            <div className="absolute top-0 h-[1px] mb-[-1px] -ml-2 w-full windowGlare" />
            <div className="hidden dark:flex flex-row items-center justify-center gap-3">
                <div className="bg-[#f46b5d] w-4 h-4 rounded-full shadow-[0_0_20px_2px_#f46b5d] border border-[rgba(16,16,16,0.1)]" />
                <div className="bg-[#f9bd4e] w-4 h-4 rounded-full shadow-[0_0_20px_2px_#f9bd4e] border border-[rgba(16,16,16,0.1)]" />
                <div className="bg-[#57c353] w-4 h-4 rounded-full shadow-[0_0_20px_2px_#57c353] border border-[rgba(16,16,16,0.1)]" />
            </div>
            <div className="flex dark:hidden flex-row items-center justify-center gap-3">
                <Button variant="ghost" className="p-0.5 w-4 h-4 rounded-full">
                    <X className="w-4 h-4" />
                </Button>
                <Button variant="ghost" className="p-0.5 w-4 h-4 rounded-full">
                    <Square className="w-4 h-4" />
                </Button>
                <Button variant="ghost" className="p-0.5 w-4 h-4 rounded-full">
                    <Circle className="w-4 h-4" />
                </Button>
            </div>
            <div className="flex flex-row space-x-2 -mr-4">
                <ToggleAudio />
                <ThemeSwitch />
            </div>
        </div>
    );
}

function WindowContent() {
    const { hero } = Config;
    let [titleFirstPart, titleSecondPart] = hero.title.split(",");
    titleFirstPart = `${titleFirstPart},`;

    const router = useRouter();
    function handleClick() {
        playAudio("/assets/audio/hover-pop.mp3");
        router.push("/about");
    };

    return (
        <div className="relative flex flex-col items-start justify-center w-full h-full p-12 sm:pt-20 sm:pb-10 sm:pl-20 sm:pr-20 gap-4">
            <div className="flex flex-col items-start justify-center gap-1">
                <h1 className="break-word sm:break-normal text-pretty text-4xl md:text-6xl lg:text-8xl font-bold">{titleFirstPart}
                    <p className="break-word sm:break-normal text-pretty dark:text-transparent dark:bg-clip-text dark:bg-gradient-to-r dark:from-neutral-100 dark:to-neutral-500"> {titleSecondPart}</p>
                </h1>
                <h4 className="mt-1 text-2xl font-light text-neutral-500">{hero.subtitle}</h4>
            </div>
            <div className="flex flex-row w-full items-start justify-center sm:justify-start gap-4">
                <Button className="text-lg w-40 h-14 sm:mt-0 mt-8" onClick={() => handleClick()}>
                    <QrCode className="w-4 h-4 mr-2" />
                    Contact
                </Button>
            </div>
            <div className="max-w-5xl hidden sm:flex flex-col items-end justify-center gap-2 ml-auto text-right">
                <h4 className="text-lg text-neutral-500">{hero.actionTitle}</h4>
                <h4 className="text-lg text-neutral-500">{hero.actionSubtitle}</h4>
            </div>
            <div className="flex w-full justify-center items-center mt-6 sm:mt-2">
                <ScrollArrow />
            </div>
        </div>
    );
}

export default function Hero() {
    return (
        <ContentCard>
            <div className="flex flex-col w-full h-full rounded-2xl border border-neutral-400 bg-neutral-800/5 backdrop-blur-xl backdrop-filter">
                <TopBar />
                <WindowContent />
            </div>
        </ContentCard>
    );
}