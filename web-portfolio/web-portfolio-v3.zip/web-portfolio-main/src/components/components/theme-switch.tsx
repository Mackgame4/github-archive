"use client";
import { Sun, Moon, SunMoon } from "lucide-react";
import { useState, useEffect } from "react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { playAudio } from "@/lib/utils";

export default function ThemeSwitch() {
    const [mounted, setMounted] = useState(false);
    const {setTheme, resolvedTheme} = useTheme();

    useEffect(() =>  setMounted(true), []);

    function handleClick() {
        playAudio("/assets/audio/soap-pop.wav");
    }

    if (!mounted) {
        return <Button variant="ghost" size="icon" className="rounded-full" onClick={() => handleClick()}>
        <SunMoon className="h-4 w-4" />
    </Button>;
    }

    if (resolvedTheme === 'dark') {
        return <Button variant="ghost" size="icon" className="rounded-full" onClick={() => {setTheme('light'); handleClick()}}>
        <Sun className="h-4 w-4" />
    </Button>;
    }

    if (resolvedTheme === 'light') {
        return <Button variant="ghost" size="icon" className="rounded-full" onClick={() => {setTheme('dark'); handleClick()}}>
            <Moon className="h-4 w-4" />
        </Button>;
    }
}