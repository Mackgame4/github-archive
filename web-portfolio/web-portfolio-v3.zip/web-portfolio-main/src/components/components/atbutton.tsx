import { Button } from "@/components/ui/button";
import Link from "next/link";
import { MoveUpRight, AtSign } from "lucide-react";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import Config from "@/lib/config";
import Image from "next/image";
import { playAudio } from "@/lib/utils";

export function PopoverElements() {
    let profileLinkedin = Config.profile.socials.find(social => social.name === "LinkedIn");
    let linkedinUrl = profileLinkedin ? profileLinkedin.url : "LinkedIn URL not found";
    return (
        <>
            <Button variant="link">
                <Link href={linkedinUrl} target="_blank" rel="noopener noreferrer" className="flex flex-row">LinkedIn<MoveUpRight className="ml-2 h-4 w-4" /></Link>
            </Button>
            <HoverCard>
                <HoverCardTrigger asChild>
                    <Button variant="link">
                        <Link href={Config.profile.resumeUrl} target="_blank" rel="noopener noreferrer" className="flex flex-row">Resume<MoveUpRight className="ml-2 h-4 w-4" /></Link>
                    </Button>
                </HoverCardTrigger>
                <HoverCardContent>
                    <Image src="/assets/resume.png" priority={false} width={800} height={800} alt="Resume" />
                </HoverCardContent>
            </HoverCard>
        </>
    );
}

export default function AtButton({ ...props }) {
    function handleClick() {
        playAudio("/assets/audio/soap-pop.wav");
    }
    return (
        <Popover>
            <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className={props.className} onClick={() => handleClick()}>
                    <AtSign className="h-6 w-6" />
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-fit flex flex-col space-y-2 p-4 rounded-lg">
                <PopoverElements />
            </PopoverContent>
        </Popover>
    );
}