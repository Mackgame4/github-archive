import { MDXRemote } from "next-mdx-remote";
//import SyntaxHighlighter from "react-syntax-highlighter";
import '@/styles/mdx.css';

/*const components = {
    h1: (props: any) => (
        <h1 {...props} className="font-bold text-4xl my-2">
            {props.children}
        </h1>
    ),
    h2: (props: any) => (
        <h2 {...props} className="font-bold text-3xl my-2">
            {props.children}
        </h2>
    ),
    h3: (props: any) => (
        <h3 {...props} className="font-bold text-2xl my-2">
            {props.children}
        </h3>
    ),
    h4: (props: any) => (
        <h4 {...props} className="font-bold text-xl my-1.5">
            {props.children}
        </h4>
    ),
    h5: (props: any) => (
        <h5 {...props} className="font-bold text-lg my-1.5">
            {props.children}
        </h5>
    ),
    h6: (props: any) => (
        <h6 {...props} className="font-bold text-base">
            {props.children}
        </h6>
    ),
    p: (props: any) => (
        <p {...props} className="text-lg">
            {props.children}
        </p>
    ),
    ul: (props: any) => (
        <ul {...props} className="list-disc list-inside">
            {props.children}
        </ul>
    ),
    ol: (props: any) => (
        <ol {...props} className="list-decimal list-inside">
            {props.children}
        </ol>
    ),
    li: (props: any) => (
        <li {...props} className="text-lg">
            {props.children}
        </li>
    ),
    a: (props: any) => (
        <a {...props} className="text-blue-500 hover:underline">
            {props.children}
        </a>
    ),
    blockquote: (props: any) => (
        <blockquote {...props} className="border-l-4 border-gray-300 pl-4">
            {props.children}
        </blockquote>
    ),
    code: (props: any) => {
        const match = /language-(\w+)/.exec(props.className || '')
        return match
            ? <SyntaxHighlighter language={match[1]} PreTag="div" {...props} />
            : <code className={props.className} {...props} />
    },
    pre: (props: any) => (
        <pre {...props} className="bg-gray-100 p-1 rounded-md">
            {props.children}
        </pre>
    ),
    inlineCode: (props: any) => (
        <code {...props} className="bg-gray-100 p-1 rounded-md">
            {props.children}
        </code>
    ),
    hr: (props: any) => (
        <hr {...props} className="border-gray-300 my-4" />
    ),
    img: (props: any) => (
        <img {...props} className="rounded-md" />
    ),
    table: (props: any) => (
        <table {...props} className="table-auto">
            {props.children}
        </table>
    ),
    thead: (props: any) => (
        <thead {...props} className="bg-gray-100">
            {props.children}
        </thead>
    ),
    tbody: (props: any) => (
        <tbody {...props} className="bg-gray-200">
            {props.children}
        </tbody>
    ),
    th: (props: any) => (
        <th {...props} className="border px-4 py-2">
            {props.children}
        </th>
    ),
    td: (props: any) => (
        <td {...props} className="border px-4 py-2">
            {props.children}
        </td>
    ),
    tr: (props: any) => (
        <tr {...props} className="border px-4 py-2">
            {props.children}
        </tr>
    ),
    strong: (props: any) => (
        <strong {...props} className="font-bold">
            {props.children}
        </strong>
    ),
    em: (props: any) => (
        <em {...props} className="italic">
            {props.children}
        </em>
    ),
    del: (props: any) => (
        <del {...props} className="line-through">
            {props.children}
        </del>
    ),
    sup: (props: any) => (
        <sup {...props} className="text-sm">
            {props.children}
        </sup>
    ),
    sub: (props: any) => (
        <sub {...props} className="text-sm">
            {props.children}
        </sub>
    ),
    br: (props: any) => (
        <br {...props} />
    ),
}*/

export default function MdxProvider({ source }: Record<string, any>) {
    return (
        <div className="mdx-content">
            <MDXRemote
                {...source}
                //components={{ ...components }}
            />
        </div>
    )
}