export default function ContentCard({ children }: Readonly<{ children: React.ReactNode }>) {
    return (
        <div className="relative p-2.5 rounded-3xl shadow-inner shadow-lg border border-[#3d3d3d] w-full h-full bg-[radial-gradient(circle_farthest-side_at_50%_0,rgba(242,242,242,0.05),rgba(0,0,0,0))] outline-offset-[-1px] shadow-[0_0_20px_2px_rgba(0,0,0,0.5)] backdrop-blur-xl backdrop-filter">
            <div className="absolute top-0 h-[1px] mb-[-1px] w-full windowGlare" />
            {children}
        </div>
    );
}