"use client";
import { motion } from "framer-motion";

export default function Loading() {
    const dotClassName = "w-2 h-2 bg-primary rounded-full shadow-[0_2px_20px_2px_white]";
    return (
        <div className="flex flex-col gap-8 items-center justify-center w-full h-full pt-24">
            <div className="flex flex-row justify-center items-center space-x-3">
                <motion.div className={dotClassName}
                    initial={{ y: 0 }}
                    animate={{ y: [0, -20, 0] }}
                    transition={{
                        duration: 2,
                        ease: "easeInOut",
                        times: [0, 0.5, 1],
                        repeat: Infinity,
                        repeatDelay: 0
                    }}
                />
                <motion.div className={dotClassName}
                    initial={{ y: 0 }}
                    animate={{ y: [0, -20, 0] }}
                    transition={{
                        duration: 2,
                        ease: "easeInOut",
                        times: [0, 0.5, 1],
                        repeat: Infinity,
                        repeatDelay: 0,
                        delay: 0.4
                    }}
                />
                <motion.div className={dotClassName}
                    initial={{ y: 0 }}
                    animate={{ y: [0, -20, 0] }}
                    transition={{
                        duration: 2,
                        ease: "easeInOut",
                        times: [0, 0.5, 1],
                        repeat: Infinity,
                        repeatDelay: 0,
                        delay: 0.8
                    }}
                />
            </div>
            <h3 className="text-lg font-light text-center text-primary">Just a moment.</h3>
        </div>
    );
}