"use client";
import { motion, useTransform } from "framer-motion";
import React, { useRef, useState, useEffect } from "react";
import { useScroll } from "framer-motion";

export default function ScrollBar() {
    const { scrollYProgress } = useScroll();
    const containerRef = useRef<HTMLDivElement>(null);
    const movingDivRef = useRef<HTMLDivElement>(null);

    const [showingScrollBar, setShowingScrollBar] = useState(false);
    const [containerHeight, setContainerHeight] = useState(0);
    const [divHeight, setDivHeight] = useState(0);
    const [isDragging, setIsDragging] = useState(false);

    useEffect(() => {
        if (containerRef.current) {
            setContainerHeight(containerRef.current.clientHeight);
        }
        if (movingDivRef.current) {
            setDivHeight(movingDivRef.current.clientHeight);
        }
    }, []);

    const y = useTransform(scrollYProgress, [0, 1], [0, containerHeight - divHeight]);

    useEffect(() => {
        let timer: NodeJS.Timeout;
        const unsubscribe = scrollYProgress.on("change", () => {
            setShowingScrollBar(true);
            if (timer) clearTimeout(timer);
            timer = setTimeout(() => {
                setShowingScrollBar(false);
            }, 1200);
        });
        return () => {
            if (timer) clearTimeout(timer);
            unsubscribe();
        };
    }, [scrollYProgress]);

    function handleScrollBarClick(event: React.MouseEvent<HTMLDivElement>) {
        const containerRect = containerRef.current?.getBoundingClientRect();
        const moveY = event.clientY - containerRect!.top;
        const scrollTo = moveY / containerHeight;
        window.scrollTo({
            top: scrollTo * (document.body.scrollHeight - window.innerHeight),
            behavior: 'smooth',
        });
    };

    function handleMouseDown() {
        setIsDragging(true);
    };

    function handleMouseUp() {
        setIsDragging(false);
    };

    function handleMouseMove(event: MouseEvent) {
        if (isDragging && containerRef.current) {
            const containerRect = containerRef.current.getBoundingClientRect();
            const moveY = event.clientY - containerRect.top;
            const scrollTo = moveY / containerHeight;
            window.scrollTo({
                top: scrollTo * (document.body.scrollHeight - window.innerHeight),
                behavior: 'smooth',
            });
        }
    };

    useEffect(() => {
        if (isDragging) {
            window.addEventListener('mousemove', handleMouseMove);
            window.addEventListener('mouseup', handleMouseUp);
        } else {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        }
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging]);

    const [scrollY, setScrollY] = useState(0);
    useEffect(() => {
        const scrolledPage = scrollYProgress.on("change", (latest) => {
            setScrollY(latest);
        });
        return () => {
            scrolledPage();
        };
    }, [scrollYProgress]);

    return (
        <>
            {scrollY < 1 && <motion.div
                className="z-50 block sm:hidden w-full h-1 bg-neutral-100 shadow-lg rounded-2xl fixed top-0 left-0 origin-center"
                style={{ scaleX: scrollYProgress }} 
            />}
            <div ref={containerRef} className="z-50 hidden sm:block w-1.5 h-40 bg-[rgba(242,242,242,0.20)] shadow-lg backdrop-blur-xl backdrop-filter fixed top-[50%] right-2 rounded-2xl transform-gpu -translate-y-1/2 transition-opacity duration-500" style={{ opacity: showingScrollBar ? 1 : 0 }} onClick={handleScrollBarClick}>
                <motion.div
                    ref={movingDivRef}
                    className="absolute top-0 left-0 w-full h-10 bg-neutral-100 rounded-xl shadow-lg cursor-grab"
                    style={{ y }}
                    onMouseDown={handleMouseDown}
                />
            </div>
        </>
    );
}