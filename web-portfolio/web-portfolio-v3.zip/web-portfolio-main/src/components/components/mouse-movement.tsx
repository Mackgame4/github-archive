"use client";
import { useRef } from "react";
import { motion } from "framer-motion";
import { RefObject, useEffect } from "react";
import { useMotionValue, useSpring, frame } from "framer-motion";

const springEffect = { damping: 30, stiffness: 50, restDelta: 0.001 };

export function useFollowPointer(ref: RefObject<HTMLElement>) {
    const xPoint = useMotionValue(0);
    const yPoint = useMotionValue(0);
    const x = useSpring(xPoint, springEffect);
    const y = useSpring(yPoint, springEffect);

    useEffect(() => {
        if (!ref.current) return;
        const handlePointerMove = ({ clientX, clientY }: MouseEvent) => {
            const element = ref.current!;
            frame.read(() => {
                xPoint.set(clientX - element.offsetLeft - element.offsetWidth / 2);
                yPoint.set(clientY - element.offsetTop - element.offsetHeight / 2);
            });
        };
        window.addEventListener("pointermove", handlePointerMove); // or: "mousemove"
        return () => window.removeEventListener("pointermove", handlePointerMove);
    }, []);

    return { x, y };
}

export default function MouseMovement() {
    const ref = useRef<HTMLDivElement>(null);
    const { x, y } = useFollowPointer(ref);

    return (
        <div className="z-10 fixed top-0 left-0 w-screen h-screen pointer-events-none select-none flex justify-center items-center overflow-hidden">
            <motion.div ref={ref} className="absolute top-0 left-[50%] w-[50px] h-[50px] rounded-full pointer-events-none bg-gradient-to-br from-neutral-400 to-neutral-500 mix-blend-screen filter blur-[50px] opacity-60" style={{ x, y }} />
        </div>
    );
}