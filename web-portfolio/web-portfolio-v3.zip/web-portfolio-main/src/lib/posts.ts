"use server";
import { PostType } from "@/lib/types";
import fs from "fs";
import path from "path";
import { serialize } from "next-mdx-remote/serialize";

const postsDirectory = path.join(process.cwd(), "_posts");

export async function getPostSlugs(): Promise<string[]> {
    try {
        return fs.readdirSync(postsDirectory).filter((file) => file.endsWith(".mdx"));
    }
    catch (error) {
        return [];
    }
}

export async function getPostBySlug(slug: string): Promise<PostType | null> {
    try {
        const realSlug = slug.replace(/\.mdx$/, "");
        const fullPath = path.join(postsDirectory, `${realSlug}.mdx`);
        const fileContents = fs.readFileSync(fullPath, "utf8");
        const source = await serialize(fileContents, { parseFrontmatter: true });
        return { ...source.frontmatter, content: source, slug: realSlug } as PostType;
    } catch (error) {
        console.error("Error reading the post file:", error);
        return null;
    }
}

export async function getAllPosts(): Promise<PostType[]> {
    const slugs = await getPostSlugs();
    const posts = await Promise.all(slugs.map((slug) => getPostBySlug(slug)));
    // Use a type guard to inform TypeScript that the array doesn't contain nulls anymore.
    return posts.filter((post): post is PostType => post !== null)
        .sort((a, b) => (a?.date && b?.date) ? (a.date > b.date ? -1 : 1) : 0);
}

export async function getAllPostsByTag(tag: string): Promise<PostType[]> {
    const posts = await getAllPosts();
    return posts.filter((post: any) => post.tags?.includes(tag));
}

type PostTypeValues = PostType['type'];
export async function getAllPostsByType(type: PostTypeValues): Promise<PostType[]> {
    const posts = await getAllPosts();
    return posts.filter((post: any) => post.type === type);
}