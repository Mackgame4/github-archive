import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { useTheme } from "next-themes";

export function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs))
}

export function getTheme() {
    const theme = useTheme().theme;
    return theme;
}

export function getThemeColor() {
    return getTheme() === "dark" ? "#000000" : "#ffffff";
}

export function getEnvKey(key: string) {
    return process.env[key];
}

export function getYear() {
    return new Date().getFullYear();
}

export function isMobile() {
    if (typeof window === 'undefined') {
        return false;
    }
    const mobileWidth = 640;
    const tabletWidth = 768;
    return window.innerWidth < mobileWidth || window.innerWidth < tabletWidth;
}

let audioEnabled = false;
export function playAudio(src: string) {
    if (!audioEnabled) {
        return;
    }
    let audio = new Audio(src);
    audio.volume = 0.3;
    if (audio && typeof Audio != "undefined") {
        audio.play();
    }
}

export function toggleAudio() {
    audioEnabled = !audioEnabled;
    return audioEnabled;
}