const Config = {
    assets: {
        badgeLogo: {
            light: "/assets/light/logo_badge.png",
            dark: "/assets/dark/logo_badge.png",
            type: "image/png",
        },
        favicon: {
            light: "/assets/favicon/logo_square.png",
            dark: "/assets/favicon/logo_square.png",
            type: "image/png",
        },
    },

    html: {
        defaultTheme: "dark", // "light" or "dark" or "system"
        title: "CodeWithFab's | Personal Portfolio",
        description: "Personal Portfolio",
        generator: "Next.js",
        themeColor: (function(defaultTheme) {
            return defaultTheme === "dark" ? "#000000" : "#ffffff";
        })("dark"),
        favicon: "/assets/favicon/logo_square.png",
        faviconType: "image/png",
        keywords: ['CodeWithFab', 'Mackgame4', 'Next.js', 'React', 'JavaScript', 'TypeScript', 'Portfolio', 'Personal', 'Web Development', 'Software Engineer', 'Website', 'Web', 'App', 'Application', 'Code', 'Programming', 'Coding', 'Developer', 'Development', 'Frontend', 'Backend', 'Fullstack', 'Full-stack', 'Stack', 'Tech', 'Technology', 'Computer Science', 'Engineering', 'Software', 'Engineering', 'Projects', 'About', 'Contact', 'Blog', 'Articles', 'Posts', 'Tutorials', 'Guides', 'Resources', 'Tools', 'Services', 'API', 'REST', 'Database' ],
        authors: [
            { name: 'Mackgame4', url: 'https://mackgame4.github.io/' }
        ],
        defaultLang: "en",
    },

    profile: {
        name: "CodeWithFab",
        badge: "Software Engineer",
        email: "fabiomagalhaes454@hotmail.com",
        phone: "+351 912 345 678",
        address: "Braga, Portugal",
        socials: [
            { name: "LinkedIn", url: "https://www.linkedin.com/in/mackgame4", handle: "@mackgame4" },
            { name: "GitHub", url: "", handle: "@mackgame4" },
            { name: "Twitter", url: "", handle: "@mackgame4" },
        ],
        resumeUrl: "https://github.com/Mackgame4/mackgame4/blob/main/precompiledresume.pdf",
    },

    tabs: [
        { label: "Work", href: "/" },
        { label: "Projects", href: "/projects" },
        { label: "About", href: "/about" }
    ],

    hero: {
        title: "Building the Future, Through Good Code",
        subtitle: "Your Vision, Our Code: Let's Create Together.",
        actionTitle: "Hi, I'm Fábio!",
        actionSubtitle: "I'm a Computer Science student at the University of Minho in Portugal. I'm passionate about technology and I'm always looking for new challenges.",
    },
};

export default Config;