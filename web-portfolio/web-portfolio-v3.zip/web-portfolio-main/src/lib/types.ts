export type PostType = {
    slug: string;
    title: string;
    subtitle?: string;
    description?: string;
    type: "experience" | "project" | "blog" | "other";
    date?: string;
    accentColor?: string;
    tags?: string[];
    link?: string;
    author?: Author;
    image?: string;
    content: any;
};

export type Author = {
    name: string;
    avatar?: string;
    url?: string;
};