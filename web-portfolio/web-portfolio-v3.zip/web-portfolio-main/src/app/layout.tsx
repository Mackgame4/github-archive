import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "@/styles/globals.css";
import { cn } from "@/lib/utils";
import Provider from "@/app/provider";
import Config from "@/lib/config";
import PageLayout from "@/app/page-layout";

const inter = Inter({ subsets: ["latin"] });

export const viewport: Viewport = {
  themeColor: Config.html.themeColor,
  colorScheme: Config.html.defaultTheme === "dark" ? "dark" : "light",
};

export const metadata: Metadata = {
  title: Config.html.title,
  description: Config.html.description,
  applicationName: Config.html.title,
  keywords: Config.html.keywords,
  authors: Config.html.authors,
  generator: Config.html.generator,
  creator: Config.html.authors[0].name,
  publisher: Config.html.authors[0].name,
  icons: {
    icon: [
      {
        media: '(prefers-color-scheme: light)',
        url: Config.html.favicon,
        href: Config.html.favicon,
        type: Config.html.faviconType,
      },
      {
        media: '(prefers-color-scheme: dark)',
        url: Config.html.favicon,
        href: Config.html.favicon,
        type: Config.html.faviconType,
      },
    ],
    shortcut: Config.html.favicon,
    apple: Config.html.favicon,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang={Config.html.defaultLang} suppressHydrationWarning className={`no-scrollbar ${Config.html.defaultTheme === "dark" ? "dark" : ""}`}>
      <body className={cn("min-h-screen bg-background antialiased", inter.className)}>
          <Provider>
            <PageLayout>
              {children}
            </PageLayout>
          </Provider>
      </body>
    </html>
  );
}