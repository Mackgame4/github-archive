import ScrollBar from "@/components/components/scrollbar";
import Header from "@/components/components/header";
import MouseMovement from "@/components/components/mouse-movement";

export default function PageLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <>
            <MouseMovement />
            <ScrollBar />
            <Header />
            <div className="z-0 fixed w-full h-screen bg-gradient-to-t dark:from-neutral-900 dark:to-neutral-800 from-neutral-50 to-neutral-100 select-none pointer-events-none dark:shadow-[0_0_200px_rgba(0,0,0,0.8)_inset]" />
            <main className="z-20 relative w-full h-screen">
                {children}
            </main>
        </>
    );
}