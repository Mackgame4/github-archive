import AboutBadge from '@/components/components/about-badge';

export default function AboutPage() {
    return (
        <div className="px-6 pt-8 pb-24 sm:px-24 sm:pt-48 sm:pb-8 w-full">
            <div className="fixed top-0 left-0 w-full h-full">
                <AboutBadge />
            </div>
        </div>
    );
}