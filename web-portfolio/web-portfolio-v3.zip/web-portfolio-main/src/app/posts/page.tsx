import ContentCard from "@/components/components/content-card";
import PostCard from "@/components/components/post-card";
import { PostType } from "@/lib/types";
import { getAllPosts } from "@/lib/posts";
import NoContent from "@/components/components/no-content";

export default async function PostsPage() {
  const posts = await getAllPosts();

  if (!posts || posts.length === 0) {
    return <NoContent />;
  }

  return (
    <div className="px-6 pt-8 pb-24 sm:px-24 sm:pt-48 sm:pb-8 w-full">
      {posts.map((post: PostType) => (
      <ContentCard key={post.slug}>
        <PostCard post={post} />
      </ContentCard>
      ))}
    </div>
  );
}