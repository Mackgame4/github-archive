import { notFound } from "next/navigation";
import { getPostBySlug } from "@/lib/posts";
import PostContent from "@/components/components/post-content";

type Params = {
  params: {
    slug: string;
  };
};

export default async function PostPage({ params }: Params) {
  const post = await getPostBySlug(params.slug);

  if (!post) {
    return notFound();
  }

  return (
    <PostContent post={post} />
  );
}