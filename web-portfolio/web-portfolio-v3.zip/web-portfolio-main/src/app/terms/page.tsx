export default function TermsPage() {
  return (
      <div className="flex flex-col items-center justify-center h-screen p-12">
          <h1 className="text-4xl font-bold text-neutral-500">Just don't resell or re-publish any open source code as being your own.</h1>
      </div>
  );
}