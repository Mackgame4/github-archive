import LoadingPage from "@/components/components/loading";

export default function Loading() {
    return (
        <LoadingPage />
    );
}