export default function CookiesPage() {
  return (
      <div className="flex flex-col items-center justify-center h-screen p-12">
          <h1 className="text-4xl font-bold text-neutral-500">This website uses cookies to improve your experience on our website. By browsing this site, you agree to our use of cookies and third-party elements on this site.</h1>
      </div>
  );
}