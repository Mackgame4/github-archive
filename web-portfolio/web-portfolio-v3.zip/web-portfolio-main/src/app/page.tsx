import HeroSection from "@/components/components/hero";
import Image from "next/image";
import Config from "@/lib/config";
import ContentCard from "@/components/components/content-card";
import PostCard from "@/components/components/post-card";
import Footer from "@/components/components/footer";
import { PostType } from "@/lib/types";
import { getAllPostsByType } from "@/lib/posts";

export default async function Home() {
  const posts = await getAllPostsByType("experience");

  return (
    <>
      <div className="px-6 pt-8 pb-24 sm:px-24 sm:pt-48 sm:pb-8 w-full">
        <div className="flex sm:hidden items-center justify-center mb-12">
          <div className="w-8 h-8">
            <Image className="dark:flex hidden" src={Config.assets.badgeLogo.dark} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
            <Image className="flex dark:hidden" src={Config.assets.badgeLogo.light} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
          </div>
        </div>
        <section className="w-full">
          <HeroSection />
        </section>
        <div className="w-full mt-8">
          {posts.map((post: PostType) => (
          <ContentCard key={post.slug}>
            <PostCard post={post} />
          </ContentCard>
          ))}
        </div>
      </div>
      <Footer />
    </>
  );
} 
