/** @type {import('next').NextConfig} */
const nextConfig = {
    reactStrictMode: true,
    swcMinify: true,
    transpilePackages: ['next-mdx-remote'], // Only if using Turbopack
    images: {
        remotePatterns: [
            { // Allow loading from all domains and its subdomains
                protocol: "https",
                hostname: "**",
            },
        ],
    },
};

export default nextConfig;