import MouseMovement from "@/components/mouse-movement";
import NavBar from "@/components/navbar";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <>
      <MouseMovement />
      <main>
        {children}
      </main>
      <div className="fixed bottom-8 z-10 w-full flex justify-center">
        <NavBar />
      </div>
    </>
  );
}