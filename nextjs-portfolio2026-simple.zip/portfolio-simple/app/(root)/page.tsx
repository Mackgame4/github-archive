import { Button } from "@/components/ui/button"
import HeroBackground from "@/components/hero-background"
import LightRays from "@/components/LightRays"
import ChangelogContent from "../../components/timeline"

function exampleContent() {
  return (
    <div>
                <p className="text-lg font-medium">Initial Release</p>
                <ul className="list-disc pl-5 mt-2 text-muted-foreground">
                  <li>Project setup with Next.js and Tailwind CSS</li>
                  <li>Added basic components: Button, Card, Tooltip</li>
                  <li>Implemented dark mode support</li>
                </ul>
              </div>
  )
}

export default function Page() {
  const releases = Array.from({ length: 15 }, (_, i) => ({
    version: `v1.0.${i + 1}`,
    date: `2024-06-${String(i + 1).padStart(2, '0')}`,
    content: exampleContent()
  }))
  return (
    <div className="relative">
    <HeroBackground />
    <div className="min-h-screen max-w-7xl mx-auto px-4 py-24 flex flex-col items-center justify-center gap-6">
        <LightRays rayLength={0.5} className="absolute inset-0 -z-10 pointer-events-none" />
        <div>
          <h1 className="font-medium">Project ready!</h1>
          <p>You may now add components and start building.</p>
          <p>We&apos;ve already added the button component for you.</p>
          <Button className="mt-2">Button</Button>
        </div>
        <div className="font-mono text-xs text-muted-foreground">
          (Press <kbd>d</kbd> to toggle dark mode)
        </div>
        <ChangelogContent releases={releases} />
      </div>
    </div>
  )
}
