import type { Metadata } from "next";
import { Lexend, Geist_Mono } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import Config from '@/lib/config';
import { cn } from "@/lib/utils";
import { TooltipProvider } from "@/components/ui/tooltip"

const fontSans = Lexend({
  subsets: ["latin"],
  variable: "--font-sans",
})

const fontMono = Geist_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
})

export const metadata: Metadata = {
  title: Config.title,
  description: Config.description,
  metadataBase: new URL(Config.baseUrl),
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="en"
      suppressHydrationWarning
      className={cn(fontMono.variable, fontSans.variable, "antialiased font-sans")}
    >
      <body>
        <ThemeProvider>
          <TooltipProvider>
            {children}
          </TooltipProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
