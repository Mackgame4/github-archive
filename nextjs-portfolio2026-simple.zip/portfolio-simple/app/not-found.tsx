'use client'
import { CircleAlert, MoveLeft } from 'lucide-react'
import { useRouter } from 'next/navigation'

import { Card, CardContent } from "@/components/ui/card"
import { Button } from '@/components/ui/button'

export default function NotFound() {
    const router = useRouter();
    return (
      <div className="relative h-screen">
        <div className="absolute inset-0">
          <div className="relative h-full w-full [&>div]:absolute [&>div]:h-full [&>div]:w-full [&>div]:bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [&>div]:dark:bg-[radial-gradient(#1c1c1c_1px,transparent_1px)] [&>div]:bg-size-[16px_16px] [&>div]:mask-[radial-gradient(ellipse_50%_50%_at_50%_50%,#000_70%,transparent_100%)]">
            <div></div>
          </div>
        </div>
        <div className="relative z-10 flex w-full h-full flex-col items-center justify-center">
            <Card className="w-full max-w-sm">
              <CardContent>
                <div className="flex flex-col items-center justify-center py-4">
                  <CircleAlert className="w-24 h-24 text-primary mb-6" />
                  <h1 className="text-5xl font-bold text-primary">404</h1>
                  <p className="text-secundary mb-6">Page not found!</p>
                  <p className="text-muted-foreground mb-6 text-center">The page you are looking for does not exist or has been moved.</p>
                  <Button size="lg" onClick={() => router.back()}>
                    <MoveLeft className="h-4 w-4" />
                    Go Back
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
    );
}