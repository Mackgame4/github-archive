import { cn } from "@/lib/utils";

export default function HeroBackground() {
    return (
        <>
            <div
            className={cn(
                "fixed inset-0 pointer-events-none -z-10",
                "bg-size-[250px_190px]",
                "bg-[linear-gradient(to_right,#e4e4e7_1px,transparent_1px),linear-gradient(to_bottom,#e4e4e7_1px,transparent_1px)]",
                "dark:bg-[linear-gradient(to_right,#262626_1px,transparent_1px),linear-gradient(to_bottom,#262626_1px,transparent_1px)]",
            )}
            />
        </>
    )
}