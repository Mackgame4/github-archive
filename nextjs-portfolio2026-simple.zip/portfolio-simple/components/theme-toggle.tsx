"use client"
import { Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"

import { Button } from "@/components/ui/button"

export function ThemeToggle() {
    const { theme, setTheme } = useTheme()
    return (
        <div onClick={() => setTheme(theme === "dark" ? "light" : "dark")} className="swap swap-rotate cursor-pointer flex items-center justify-center w-10 h-8">
            <Sun className="w-4 h-4 sm:w-5 sm:h-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="w-4 h-4 sm:w-5 sm:h-5 absolute rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
        </div>
    )
}