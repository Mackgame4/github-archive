"use client";
import { useState, useEffect } from "react";
import { navItems, navLinks } from "@/lib/navmenu";
import { useRouter, usePathname } from "next/navigation";
import { ThemeToggle } from "@/components/theme-toggle";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip"

export default function NavMenu() {
    const tabs = navItems;
    const pathname = usePathname();
    const router = useRouter();
    const [activeTab, setActiveTab] = useState(() => {
        const index = tabs.findIndex((tab) => tab.path === pathname);
        return index !== -1 ? index : 0;
    });

    function handleTabClick(index: number) {
        setActiveTab(index);
        router.push(tabs[index].path);
    }

    useEffect(() => {
        const index = tabs.findIndex((tab) => tab.path === pathname);
        if (index !== -1) {
            setActiveTab(index);
        }
    }, [pathname]);

    return (
        <>
            <div className="flex bg-[rgba(242,242,242,0.05)] border dark:border-[rgba(242,242,242,0.1)] border-gray-200 rounded-full justify-between items-center w-fit h-fit p-1.5 relative shadow-[0_10px_25px_rgba(0,0,0,0.15)] select-none backdrop-blur-xl backdrop-filter">
                {tabs.map((tab, index) => (
                    <Tooltip key={index}>
                        <TooltipTrigger render={
                            <div onClick={() => handleTabClick(index)} className="cursor-pointer relative rounded-full px-3 py-2 text-sm font-medium dark:text-white text-black transition focus-visible:outline-2">
                            {activeTab === index && (
                                <div className="flex justify-center items-center absolute inset-0 -z-10 rounded-full dark:bg-[rgba(242,242,242,0.05)] bg-[rgba(0,0,0,0.05)]">
                                    <div className="absolute -top-2.5 dark:bg-white bg-black rounded-xs w-6 h-1 shadow-[0_2px_25px_2px_white]" />
                                </div>
                            )}
                            {tab.icon && <div className="flex items-center justify-center w-4 h-4 sm:w-6 sm:h-7">{tab.icon}</div>}
                            </div>
                        }>
                        </TooltipTrigger>
                        <TooltipContent side="bottom">
                            {tab.name}
                        </TooltipContent>
                    </Tooltip>
                ))}
                <div className="w-px h-6 bg-foreground opacity-12 mx-2" />
                {navLinks.map((link, index) => (
                    <Tooltip key={index}>
                        <TooltipTrigger render={
                            <a href={link.url} target="_blank" rel="noopener noreferrer" className="cursor-pointer relative rounded-full px-3 py-2 text-sm font-medium dark:text-white text-black transition focus-visible:outline-2">
                                {link.icon && <div className="flex items-center justify-center w-4 h-4 sm:w-6 sm:h-7">{link.icon}</div>}
                            </a>
                        }>
                        </TooltipTrigger>
                        <TooltipContent side="bottom">
                            {link.name}
                        </TooltipContent>
                    </Tooltip>
                ))}
                <div className="w-px h-6 bg-foreground opacity-12 mx-2" />
                <ThemeToggle />
            </div>
        </>
    );
}