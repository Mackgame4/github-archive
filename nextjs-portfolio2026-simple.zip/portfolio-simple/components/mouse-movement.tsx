"use client";
import { useEffect, useRef } from "react";

export default function MouseMovement() {
    const pos = useRef({ x: 0, y: 0 });
    const target = useRef({ x: 0, y: 0 });
    const velocity = useRef({ x: 0, y: 0 });
    const elRef = useRef<HTMLDivElement>(null);

    const FOLLOW = 0.03;
    const DAMPING = 0.1;

    useEffect(() => {
        function onMouseMove(e: MouseEvent) {
            target.current.x = e.clientX - window.innerWidth / 2;
            target.current.y = e.clientY - window.innerHeight / 2;
        }
        window.addEventListener("mousemove", onMouseMove);
        
        let raf: number;
        const animate = () => {
            const dx = target.current.x - pos.current.x;
            const dy = target.current.y - pos.current.y;
            velocity.current.x = velocity.current.x * DAMPING + dx * FOLLOW;
            velocity.current.y = velocity.current.y * DAMPING + dy * FOLLOW;
            pos.current.x += velocity.current.x;
            pos.current.y += velocity.current.y;
            if (elRef.current) {
                elRef.current.style.transform =
                `translate3d(${pos.current.x}px, ${pos.current.y}px, 0)`;
            }
            raf = requestAnimationFrame(animate);
        };

        raf = requestAnimationFrame(animate);

        return () => {
            cancelAnimationFrame(raf);
            window.removeEventListener("mousemove", onMouseMove);
        };
    }, []);

    return (
        <div className="-z-10 fixed inset-0 pointer-events-none overflow-hidden">
            <div
                ref={elRef}
                className="absolute left-1/2 top-1/2 w-0 h-0 rounded-full"
                style={{
                boxShadow: `
                    0 0 94px 10px rgba(180,180,180,0.35),
                    0 0 96px 68px rgba(180,180,180,0.08)
                `,
                mixBlendMode: "screen",
                willChange: "transform",
                }}
            />
        </div>
    );
}