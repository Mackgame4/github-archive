import { Home, FolderOpen, FileText, Linkedin, Github } from 'lucide-react';

export const navItems = [
    { name: 'About', path: '/', icon: <Home className='w-5 h-5' /> },
    { name: 'Blog', path: '/blog', icon: <FolderOpen className='w-5 h-5' /> },
];

export const navLinks = [
    { name: 'CV', url: 'https://www.linkedin.com/', icon : <FileText className='w-5 h-5' /> },
    { name: 'GitHub', url: 'https://www.linkedin.com/', icon : <Github className='w-5 h-5' /> },
    { name: 'LinkedIn', url: 'https://www.linkedin.com/', icon : <Linkedin className='w-5 h-5' /> }
]