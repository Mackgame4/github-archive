declare module "equal-vue";
