declare module "equal-vue";
