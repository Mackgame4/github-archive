"use client";
import Link from 'next/link';
import Image from 'next/image';
import React, { useState, type ReactElement } from 'react';
import type { ImageProps } from 'next/image';
import { Sparkles, ExternalLink, Info, AlertCircle, CircleCheck, CircleX } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export function CustomLink(props: { href?: string, children: React.ReactNode, [key: string]: any }) {
  const href = props.href || '';
  if (href.startsWith('/')) {
    return (
      <Link href={href} {...props}>
        {props.children}
      </Link>
    )
  }
  if (href.startsWith('#')) {
    return <a {...props} />
  }
  return <div>
    <ExternalLink className="inline mb-0.5 mr-1.5 h-4 w-4" />
    <a target="_blank" rel="noopener noreferrer" {...props} />
  </div>
}

export function HighlightCard({ children, ...props }: { children: React.ReactNode, title?: string, subtitle?: string, color?: string }) {
  const extractRGB = (color: string) => {
    const rgb = color.split(',');
    return rgb.map((c: string) => parseInt(c.trim()));
  };
  const [r, g, b] = extractRGB(props.color || '255, 255, 255'); // Default to white if no color provided
  return (
    <div className="flex flex-col justify-center items-center relative border border-neutral-200 dark:border-neutral-800 rounded-xl p-4 my-4 bg-neutral-50/50 dark:bg-neutral-900/65" style={{ backgroundImage: `radial-gradient(circle closest-corner at 50% 0, rgba(${r}, ${g}, ${b}, .05), rgba(0, 0, 0, 0))`}}>
      <div className="border-none h-[1px] absolute -top-0.5 left-0 w-full px-4" style={{ background: `linear-gradient(to right, rgba(0, 0, 0, 0) 15%, rgba(${r}, ${g}, ${b}, 0.5) 50%, rgba(0, 0, 0, 0) 95%)` }} />
      <div className="flex rounded-full bg-neutral-200 dark:bg-neutral-900/35 w-12 h-12 mb-3 justify-center items-center" style={{ backgroundImage: `radial-gradient(circle closest-corner at 50% 50%, rgba(${r}, ${g}, ${b}, .1), rgba(0, 0, 0, 0))`}}>
        <Sparkles className="h-5 w-5" style={{ color: `rgb(${r}, ${g}, ${b})` }} />
      </div>
      <span className="text-xs uppercase text-muted-foreground">{props.subtitle}</span>
      <span className="text-2xl font-medium text-center tracking-tight mt-4 mb-2">{props.title}</span>
      {children}
    </div>
  )
}

export function ContextSection({ children, ...props }: { children: React.ReactNode, title?: string, subtitle?: string, description?: string, color?: string, className?: string }) {
  const extractRGB = (color: string) => {
    const rgb = color.split(',');
    return rgb.map((c: string) => parseInt(c.trim()));
  };
  const [r, g, b] = extractRGB(props.color || '255, 255, 255'); // Default to white if no color provided
  return (
    <div className={`grid grid-cols-2 gap-2 ${props.className || ''}`}>
      <div className="flex flex-col justify-start items-start">
        {props.subtitle &&
        <div className="flex flex-row space-x-2 mb-2 justify-center items-center">
            <div className="rounded-full w-2 h-2" style={{ boxShadow: `0 0 20px rgb(${r}, ${g}, ${b})`, backgroundColor: `rgb(${r}, ${g}, ${b})` }}></div>
            <span className="ml-0.5 text-xs uppercase text-muted-foreground">{props.subtitle}</span>
        </div>
        }
        <span className="text-2xl font-medium text-center tracking-tight my-2">{props.title}</span>
        <span className="text-sm text-muted-foreground mt-6">{props.description}</span>
      </div>
      <div className="flex flex-col justify-start items-start">
        {children}
      </div>
    </div>
  )
}

export function AlertComponent({ children, ...props }: { children: React.ReactNode, className?: string, type?: 'info' | 'warning' | 'destructive' | 'success', title?: string }) {
  const IconComponent = props.type == 'info' ? Info : props.type == 'warning' ? AlertCircle : props.type == 'destructive' ? CircleX : props.type == 'success' ? CircleCheck : null;
  return <Alert className={`border border-muted ${props.className || ''}`} variant={props.type == 'destructive' ? 'destructive' : 'default'}>
    {IconComponent && <IconComponent className="h-4 w-4 mr-2" />}
    <AlertTitle>{props.title}</AlertTitle>
    <AlertDescription>{children}</AlertDescription>
  </Alert>
}

export function Accordion({ children, className, color }: { children: React.ReactNode, className?: string, color?: string }) {
  const items = React.Children.toArray(children);
  const extractRGB = (color: string) => {
    const rgb = color.split(',');
    return rgb.map((c: string) => parseInt(c.trim()));
  };
  const [r, g, b] = extractRGB(color || '255, 255, 255'); // Default to white if no color provided
  return (
    <div className={`space-y-1 ${className || ""}`} style={{ backgroundImage: `radial-gradient(circle closest-corner at 50% 0, rgba(${r}, ${g}, ${b}, .05), rgba(0, 0, 0, 0))` }}>
      {items.map((child, index) => {
        if (!React.isValidElement(child)) return child;
        const element = child as ReactElement<{ className?: string }>;
        const isFirst = index === 0;
        const isLast = index === items.length - 1;
        return React.cloneElement(element, {
          className: [
            element.props.className,
            "p-5 bg-secondary/40 text-sm",
            isFirst ? "rounded-sm rounded-t-3xl" : "",
            isLast ? "rounded-sm rounded-b-3xl" : "",
            !isFirst && !isLast ? "rounded-sm" : "",
          ]
            .filter(Boolean)
            .join(" "),
        })
      })}
    </div>
  )
}

export function AccordionItem({ children, className }: { children: React.ReactNode, className?: string}) {
  return <div className={className}>{children}</div>
}

export function Divider(props: { className?: string }) {
  return <hr className={`border-neutral-200 dark:border-neutral-800 ${props.className || ''}`} />
}

export function RoundedImage(props: ImageProps) {
  const imageType = props.src?.toString().split('.').pop()?.toUpperCase() || 'IMAGE';
  return <ExternalContent contentType={imageType} alt={props.alt}>
    <Image className="rounded-2xl w-full h-auto" {...props} />
  </ExternalContent>
}

export function Video({ children, ...props }: { children: React.ReactNode, [key: string]: any }) {
  const videoType = props.src?.toString().split('.').pop()?.toUpperCase() || 'VIDEO';
  return <ExternalContent contentType={videoType} alt={props.alt}>
    <video controls preload="metadata" className="w-full h-auto rounded-2xl">
      <source src={props.src} type={props.type || 'video/mp4'} />
      Your browser does not support the video tag.
    </video>
  </ExternalContent>
}

export function Iteractive(props: any) {
  const contentType = 'ITERACTIVE';
  const [checked, setChecked] = useState(false);
  return <ExternalContent contentType={contentType} alt={props.alt} footer={
      <div className="flex items-center space-x-2">
        <Switch checked={checked} onCheckedChange={setChecked} />
        <Badge variant="outline" className="text-xs text-muted-foreground rounded-full">{props.action}</Badge>
      </div>
    }>
    <Image className="rounded-2xl w-full h-auto" src={checked ? props.final : props.init} alt={props.alt} width={props.width} height={props.height} />
  </ExternalContent>
}

export function ExternalContent({ children, footer, contentType, ...props }: { children: React.ReactNode, footer?: React.ReactNode, alt?: string, contentType?: string }) {
  return <div className="overflow-hidden">
    <div className="rounded-2xl border border-muted bg-card text-center items-center justify-center">
      {children}
    </div>
    <div className="flex w-full items-center justify-between my-2">
      {footer || <div></div>}
      <div className="flex items-center space-x-2">
        <span className="text-xs text-muted-foreground">{props.alt}</span>
        <Badge variant="secondary" className="text-xs text-muted-foreground rounded-full">{contentType}</Badge>
      </div>
    </div>
  </div>
}

export function Code({ children, ...props }: { children: React.ReactNode | string, [key: string]: any }) {
  const codeHTML = children
  return <div className="my-4 bg-card p-3 rounded-lg font-mono text-sm border border-muted overflow-x-auto">
    <code dangerouslySetInnerHTML={{ __html: codeHTML! }} {...props} />
  </div>
}