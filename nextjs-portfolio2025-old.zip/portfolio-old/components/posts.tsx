import Link from 'next/link';
import { ViewTransition } from 'react';

import { formatDate, getBlogPosts } from '@/lib/blog';

export function BlogPosts({ filterTags, filteredTags }: { filterTags?: string[], filteredTags?: string[] }) {
    const blogPosts = getBlogPosts()
    .filter((post) => {
        if (!filteredTags || filteredTags.length === 0) {
            return true;
        }
        const postTags = post.metadata.tags?.map(t => t.toLowerCase()) ?? [];
        return !filteredTags.some((tag) => postTags.includes(tag.toLowerCase()));
    })
    .filter((post) => {
        if (!filterTags || filterTags.length === 0) {
            return true;
        }
        const postTags = post.metadata.tags?.map(t => t.toLowerCase()) ?? [];
        return filterTags.some((tag) => postTags.includes(tag.toLowerCase()));
    })
    .sort((a, b) => {
        if (new Date(a.metadata.publishedAt!) > new Date(b.metadata.publishedAt!)) {
            return -1;
        }
        return 1;
    });
    return (
        <>
        {blogPosts.map((post) => (
            <Link key={post.slug} className="flex flex-col space-y-1 mb-4" href={`/blog/${post.slug}`}>
                <div className="grid grid-cols-[7rem_1fr] gap-3 items-start">
                    <ViewTransition name={`post-date-${post.slug}`}>
                        <span className="text-neutral-600 dark:text-neutral-400 tabular-nums leading-tight block">
                            {formatDate(post.metadata.publishedAt!, false)}
                        </span>
                    </ViewTransition>
                    <ViewTransition name={`post-title-${post.slug}`}>
                        <h2 className="text-neutral-900 dark:text-neutral-100 tracking-tight">
                            {post.metadata.title}
                        </h2>
                    </ViewTransition>
                </div>
            </Link>
        ))}
        </>
    )
}