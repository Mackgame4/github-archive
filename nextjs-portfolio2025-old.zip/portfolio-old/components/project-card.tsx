"use client"
import React from 'react'
import { Card, CardDescription, CardTitle, CardContent } from "@/components/ui/card"
import { ViewTransition } from 'react'
import Image from "next/image";

import { cn } from '@/lib/utils'

export interface ProjectCardProps {
    className?: string
    color?: string
    title: string
    description: string
    slug: string
    imageSrc?: string
}

export default function ProjectCard({
    className,
    title,
    description,
    slug,
    imageSrc = "/thumbnail.png",
    color = "255, 255, 255"
}: ProjectCardProps) {
    const handleCardMove: React.MouseEventHandler<HTMLElement> = e => {
        const c = e.currentTarget as HTMLElement
        const rect = c.getBoundingClientRect()
        c.style.setProperty('--mouse-x', `${e.clientX - rect.left}px`)
        c.style.setProperty('--mouse-y', `${e.clientY - rect.top}px`)
    }

    const [r, g, b] = color ? color.split(',') : [59, 130, 246]; // Default to blue if no color provided

    return (
        <Card
            onMouseMove={handleCardMove}
            className={cn("group relative w-full h-75 overflow-hidden cursor-pointer", className)}
            style={{
                '--hover-color': `rgba(${r}, ${g}, ${b}, 0.4)`,
            } as React.CSSProperties}
        >
            <div className="absolute top-0 h-px w-full bg-linear-to-r from-transparent via-white to-transparent opacity-60 z-10" />
            <ViewTransition name={`post-color-${slug}`}>
            <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none z-10"
                style={{
                background:
                    'radial-gradient(circle at var(--mouse-x) var(--mouse-y), var(--hover-color), transparent 70%)'
                }}
            />
            </ViewTransition>
            <CardContent className="absolute top-0 left-0 p-0 flex flex-col h-full">
                <div className="relative w-full flex-1">
                    <ViewTransition name={`post-cover-${slug}`}>
                    <Image
                        src={imageSrc}
                        alt="Project Thumbnail"
                        fill
                        className="object-cover"
                    />
                    </ViewTransition>
                </div>
                <div className="p-4 flex flex-col justify-center">
                    <ViewTransition name={`post-title-${slug}`}>
                    <CardTitle className="text-lg font-bold line-clamp-1">
                        {title}
                    </CardTitle>
                    </ViewTransition>
                    <CardDescription className="text-sm text-foreground/50 line-clamp-2">
                        {description}
                    </CardDescription>
                </div>
            </CardContent>
        </Card>
    )
}