import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

import { getBlogPosts } from '@/lib/blog';
import ProjectCard from '@/components/project-card';
import Link from 'next/link';

export default function HeroProjects({ filteredTags }: { filteredTags?: string[] }) {
  const blogPosts = getBlogPosts()
  .filter((post) => {
      if (!filteredTags || filteredTags.length === 0) {
          return true;
      }
      const postTags = post.metadata.tags?.map(t => t.toLowerCase()) ?? [];
      return !filteredTags.some((tag) => postTags.includes(tag.toLowerCase()));
  })
  .sort((a, b) => {
      if (new Date(a.metadata.publishedAt!) > new Date(b.metadata.publishedAt!)) {
          return -1;
      }
      return 1;
  });
  return (
      <main className="mt-12 w-full px-6 relative">
          <div className="flex flex-col items-center text-center">
              <Badge className="shadow-[0_0_15px_white] bg-white text-black">
                  My Projects
              </Badge>
              <h1 className="text-4xl md:text-6xl font-bold mt-6 max-w-4xl">
                  A showcase of my work and passion projects
              </h1>
              <p className="text-lg md:text-xl mt-4 max-w-2xl text-muted-foreground">
                  From game development to web applications, explore a diverse range of
                  projects that highlight my skills and creativity.
              </p>
          </div>
          <div className="relative mt-16 mx-24">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {blogPosts.slice(0, 8).map((post) => (
                <Link key={post.slug} href={`/blog/${post.slug}`} className="w-full">
                  <ProjectCard color={post.metadata.color} title={post.metadata.title as string} description={post.metadata.summary as string} imageSrc={post.metadata.cover as string} slug={post.slug} />
                </Link>
              ))}
            </div>
            <div className="pointer-events-none absolute bottom-0 left-0 w-full h-40 bg-linear-to-t from-background to-transparent" />
          </div>
          <div className="flex justify-center mt-10">
            <Link href="/blog">
              <Button variant="outline" size="lg">
                See More Projects
              </Button>
            </Link>
          </div>
      </main>
  )
}
