import ThreeComputer from '@/components/3d/three-computer';

export default function HeroPage() {
    return (
        <main className='pt-24 h-screen w-full'>
            <div className="
                absolute inset-0 
                -z-10 
                opacity-20 
                pointer-events-none
                bg-[url('/square-grid-overlay.png')] 
            "></div>
            <ThreeComputer />
        </main>
    );
}