"use client";
import Navbar from '@/components/navbar';
import Image from "next/image";
import Config from "@/lib/config";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import { MoveUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function Header() {
    const [scrollY, setScrollY] = useState(0);
    useEffect(() => {
        function onScroll() {
            setScrollY(window.scrollY / window.innerHeight);
        }
        window.addEventListener("scroll", onScroll);
        return () => {
            window.removeEventListener("scroll", onScroll);
        };
    }, []);
    return (
        <div className={cn("z-50 fixed top-0 left-0 flex justify-center items-center w-full px-24 py-20 pointer-events-none transition-all duration-300", scrollY > 0.025 ? "px-14 py-12" : "")}>
            <div className="z-20 flex items-center space-x-3 mr-auto pointer-events-auto">
                <div className="hidden sm:flex items-center justify-center w-8 h-8">
                    <Image className="dark:invert" src={Config.assets.badgeLogo.dark} priority width={34} height={34} alt="Logo" style={{ width: 'auto', height: 'auto' }} />
                </div>
                <div className="hidden lg:flex flex-col ml-4 text-sm font-light">
                    <span className="text-primary text-xl font-bold">{Config.profile.name}</span>
                    <p className="text-secundary">{Config.profile.badge}</p>
                </div>
            </div>
            <div className="fixed bottom-5 z-10 sm:absolute sm:left-0 sm:right-0 sm:bottom-0 sm:top-0 flex items-center justify-center">
                <div className="pointer-events-auto">
                    <Navbar />
                </div>
            </div>
            <div className="z-20 ml-auto pointer-events-auto">
                <Button variant="link">
                    <Link href={Config.profile.socials.linkedin.url} target="_blank" rel="noopener noreferrer" className="flex flex-row">LinkedIn<MoveUpRight className="ml-2 h-4 w-4" /></Link>
                </Button>
                <Button variant="link">
                    <Link href={Config.profile.socials.linkedin.url} target="_blank" rel="noopener noreferrer" className="flex flex-row">Resume<MoveUpRight className="ml-2 h-4 w-4" /></Link>
                </Button>
            </div>
        </div>
    );
}