"use client";
import React from "react";
import {cn} from "@/lib/utils";

type MarqueeProps = {
    children: React.ReactNode;
    duration?: number; // seconds
    reverse?: boolean;
    pauseOnHover?: boolean;
    className?: string;
};

export function Marquee({
    children,
    duration = 20,
    reverse = false,
    className,
}: MarqueeProps) {
    return (
        <div className={cn("relative overflow-hidden w-full", className)}>
            <div
                className="flex w-max will-change-transform animate-marquee"
                style={{ "--marquee-duration": `${duration}s`, animationDirection: reverse ? "reverse" : "normal"} as React.CSSProperties}
            >
                <div className="flex shrink-0">{children}</div>
                <div className="flex shrink-0">{children}</div>
            </div>
            <style jsx>{`
                @keyframes marquee {
                    from {
                        transform: translateX(0);
                    }
                    to {
                        transform: translateX(-50%);
                    }
                }
                .animate-marquee {
                    animation: marquee var(--marquee-duration) linear infinite;
                }
            `}</style>
        </div>
    );
}
