// @ts-nocheck
'use client'

import * as THREE from 'three'
import { useEffect, useRef, useState } from 'react'
import { Canvas, extend, useThree, useFrame } from '@react-three/fiber'
import { useGLTF, useTexture, Environment, Lightformer } from '@react-three/drei'
import {
  BallCollider,
  CuboidCollider,
  Physics,
  RigidBody,
  useRopeJoint,
  useSphericalJoint,
} from '@react-three/rapier'
import { MeshLineGeometry, MeshLineMaterial } from 'meshline'

extend({ MeshLineGeometry, MeshLineMaterial })

useGLTF.preload('/3d/Scene.glb')
useTexture.preload('/3d/band.jpg')
useTexture.preload('/profilepicture.png')

export default function AboutBadge() {
  const zoom = 39
  const bandPosition = [0, -1, 0]

  return (
    <Canvas camera={{ position: [0, 0, zoom], fov: 25 }}>
      <ambientLight intensity={Math.PI} />
      <Scene bandPosition={bandPosition} />
    </Canvas>
  )
}

function Scene({ bandPosition }) {
  return (
    <>
      <BackgroundImage />

      <Physics interpolate gravity={[0, -30, 0]} timeStep={1 / 60}>
        <Band bandPosition={bandPosition} />
      </Physics>

      <Environment blur={0.75}>
        <Lightformer intensity={2} position={[0, -1, 5]} rotation={[0, 0, Math.PI / 3]} scale={[100, 0.1, 1]} />
        <Lightformer intensity={3} position={[-1, -1, 1]} rotation={[0, 0, Math.PI / 3]} scale={[100, 0.1, 1]} />
        <Lightformer intensity={3} position={[1, 1, 1]} rotation={[0, 0, Math.PI / 3]} scale={[100, 0.1, 1]} />
        <Lightformer intensity={10} position={[-10, 0, 14]} rotation={[0, Math.PI / 2, Math.PI / 3]} scale={[100, 10, 1]} />
      </Environment>
    </>
  )
}

function BackgroundImage() {
  const texture = useTexture('/profilepicture.png')
  const { viewport } = useThree()

  texture.colorSpace = THREE.SRGBColorSpace

  const imageAspect = texture.image.width / texture.image.height
  const viewportAspect = viewport.width / viewport.height

  let width = viewport.width
  let height = viewport.height

  if (viewportAspect > imageAspect) {
    height = width / imageAspect
  } else {
    width = height * imageAspect
  }

  return (
    <mesh position={[0, 0, -10]}>
      <planeGeometry args={[width, height]} />
      <meshBasicMaterial map={texture} toneMapped={false} />
    </mesh>
  )
}

/* =========================
   BAND / BADGE
========================= */

function Band({ maxSpeed = 50, minSpeed = 10, bandPosition }) {
  const band1 = useRef()
  const band2 = useRef()

  // Band 1 (left)
  const fixed1 = useRef()
  const j1_1 = useRef()
  const j2_1 = useRef()
  const j3_1 = useRef()

  // Band 2 (right)
  const fixed2 = useRef()
  const j1_2 = useRef()
  const j2_2 = useRef()
  const j3_2 = useRef()

  const card = useRef()

  const vec = new THREE.Vector3()
  const ang = new THREE.Vector3()
  const rot = new THREE.Vector3()
  const dir = new THREE.Vector3()

  const segmentProps = {
    type: 'dynamic',
    canSleep: true,
    colliders: false,
    angularDamping: 2,
    linearDamping: 2,
  }

  const { nodes, materials } = useGLTF('/3d/Scene.glb')
  const texture = useTexture('/3d/band.jpg')
  const { width, height } = useThree((s) => s.size)

  const [curve1] = useState(() => new THREE.CatmullRomCurve3([new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()]))
  const [curve2] = useState(() => new THREE.CatmullRomCurve3([new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()]))

  const [dragged, drag] = useState(false)
  const [hovered, hover] = useState(false)

  // Rope joints for left band
  useRopeJoint(fixed1, j1_1, [[0, 0, 0], [0, 0, 0], 1])
  useRopeJoint(j1_1, j2_1, [[0, 0, 0], [0, 0, 0], 1])
  useRopeJoint(j2_1, j3_1, [[0, 0, 0], [0, 0, 0], 1])
  useSphericalJoint(j3_1, card, [[0, 0, 0], [0, 1.45, 0]])

  // Rope joints for right band
  useRopeJoint(fixed2, j1_2, [[0, 0, 0], [0, 0, 0], 1])
  useRopeJoint(j1_2, j2_2, [[0, 0, 0], [0, 0, 0], 1])
  useRopeJoint(j2_2, j3_2, [[0, 0, 0], [0, 0, 0], 1])
  useSphericalJoint(j3_2, card, [[0, 0, 0], [0, 1.45, 0]])

  useEffect(() => {
    if (!hovered) return
    document.body.style.cursor = dragged ? 'grabbing' : 'grab'
    return () => (document.body.style.cursor = 'auto')
  }, [hovered, dragged])

  useFrame((state, delta) => {
    if (dragged) {
      vec.set(state.pointer.x, state.pointer.y, 0.5).unproject(state.camera)
      dir.copy(vec).sub(state.camera.position).normalize()
      vec.add(dir.multiplyScalar(state.camera.position.length()))

      ;[card, j1_1, j2_1, j3_1, fixed1, j1_2, j2_2, j3_2, fixed2].forEach((r) => r.current?.wakeUp())

      card.current?.setNextKinematicTranslation({
        x: vec.x - dragged.x,
        y: vec.y - dragged.y,
        z: vec.z - dragged.z,
      })
    }

    // Update curves for both bands
    ;[j1_1, j2_1].forEach((r) => {
      if (!r.current.lerped) r.current.lerped = new THREE.Vector3().copy(r.current.translation())
      r.current.lerped.lerp(
        r.current.translation(),
        delta * (minSpeed + Math.min(1, r.current.lerped.distanceTo(r.current.translation())) * (maxSpeed - minSpeed))
      )
    })
    curve1.points[0].copy(j3_1.current.translation())
    curve1.points[1].copy(j2_1.current.lerped)
    curve1.points[2].copy(j1_1.current.lerped)
    curve1.points[3].copy(fixed1.current.translation())
    band1.current.geometry.setPoints(curve1.getPoints(32))

    ;[j1_2, j2_2].forEach((r) => {
      if (!r.current.lerped) r.current.lerped = new THREE.Vector3().copy(r.current.translation())
      r.current.lerped.lerp(
        r.current.translation(),
        delta * (minSpeed + Math.min(1, r.current.lerped.distanceTo(r.current.translation())) * (maxSpeed - minSpeed))
      )
    })
    curve2.points[0].copy(j3_2.current.translation())
    curve2.points[1].copy(j2_2.current.lerped)
    curve2.points[2].copy(j1_2.current.lerped)
    curve2.points[3].copy(fixed2.current.translation())
    band2.current.geometry.setPoints(curve2.getPoints(32))

    ang.copy(card.current.angvel())
    rot.copy(card.current.rotation())
    card.current.setAngvel({
      x: ang.x,
      y: ang.y - rot.y * 0.25,
      z: ang.z,
    })
  })

  curve1.curveType = 'chordal'
  curve2.curveType = 'chordal'
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping

  // Offsets for 45 degree V-shape
  const offset = 1.5
  const leftPos = [-offset, 0, 0]   // 45 deg left
  const rightPos = [offset, 0, 0]   // 45 deg right

  return (
    <>
      {/* Band 1 */}
      <group position={leftPos}>
        <RigidBody ref={fixed1} {...segmentProps} type="fixed" />
        <RigidBody position={[0.5, 0, 0]} ref={j1_1} {...segmentProps}><BallCollider args={[0.1]} /></RigidBody>
        <RigidBody position={[1, 0, 0]} ref={j2_1} {...segmentProps}><BallCollider args={[0.1]} /></RigidBody>
        <RigidBody position={[1.5, 0, 0]} ref={j3_1} {...segmentProps}><BallCollider args={[0.1]} /></RigidBody>
      </group>

      {/* Band 2 */}
      <group position={rightPos}>
        <RigidBody ref={fixed2} {...segmentProps} type="fixed" />
        <RigidBody position={[0.5, 0, 0]} ref={j1_2} {...segmentProps}><BallCollider args={[0.1]} /></RigidBody>
        <RigidBody position={[1, 0, 0]} ref={j2_2} {...segmentProps}><BallCollider args={[0.1]} /></RigidBody>
        <RigidBody position={[1.5, 0, 0]} ref={j3_2} {...segmentProps}><BallCollider args={[0.1]} /></RigidBody>
      </group>

      {/* Badge */}
      <RigidBody
        position={[2, 0, 0]}
        ref={card}
        {...segmentProps}
        type={dragged ? 'kinematicPosition' : 'dynamic'}
      >
        <CuboidCollider args={[0.8, 1.125, 0.01]} />

        <group
          scale={2.25}
          position={[0, -1.2, -0.05]}
          onPointerOver={() => hover(true)}
          onPointerOut={() => hover(false)}
          onPointerDown={(e) => {
            e.target.setPointerCapture(e.pointerId)
            drag(new THREE.Vector3().copy(e.point).sub(vec.copy(card.current.translation())))
          }}
          onPointerUp={(e) => {
            e.target.releasePointerCapture(e.pointerId)
            drag(false)
          }}
        >
          <mesh geometry={nodes.card.geometry}>
            <meshPhysicalMaterial
              map={materials.base.map}
              map-anisotropy={16}
              clearcoat={1}
              clearcoatRoughness={0.15}
              roughness={0.3}
              metalness={0.5}
            />
          </mesh>

          <mesh geometry={nodes.clip.geometry} material={materials.metal} material-roughness={0.3} />
          <mesh geometry={nodes.clamp.geometry} material={materials.metal} />
        </group>
      </RigidBody>

      {/* MeshLine bands */}
      <mesh ref={band1}>
        <meshLineGeometry />
        <meshLineMaterial
          color="white"
          depthTest={false}
          resolution={[width, height]}
          useMap
          map={texture}
          repeat={[-3, 1]}
          lineWidth={1}
        />
      </mesh>

      <mesh ref={band2}>
        <meshLineGeometry />
        <meshLineMaterial
          color="white"
          depthTest={false}
          resolution={[width, height]}
          useMap
          map={texture}
          repeat={[-3, 1]}
          lineWidth={1}
        />
      </mesh>
    </>
  )
}
