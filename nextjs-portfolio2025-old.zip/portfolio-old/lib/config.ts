export default {
    baseUrl: process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000',
    lang: 'en',
    title: 'CodeWithFab - Portfolio',
    description: 'A personal portfolio featuring my projects, technical blog posts, and hands-on experiments in development.',

    navItems: [
        { name: 'Home', path: '/' },
        { name: 'Blog', path: '/blog' },
        { name: 'About', path: '/about' }
    ],

    profile: {
        name: "CodeWithFab",
        badge: "Software Engineer",
        email: "fabiomagalhaes454@hotmail.com",
        address: "Braga, Portugal",
        socials: {
            linkedin: { url: "https://www.linkedin.com/in/fabiomagalhaes104365/", handle: "@fabiomagalhaes104365" },
            github: { url: "https://github.com/Mackgame4", handle: "@mackgame4" },
            twitch: { url: "https://www.twitch.tv/mackgame4", handle: "@mackgame4" },
        },
        resumeUrl: "https://github.com/Mackgame4/mackgame4/blob/main/precompiledresume.pdf",
    },

    assets: {
        badgeLogo: {
            light: "/logo_badge.png",
            dark: "/logo_badge.png",
            type: "image/png",
        },
        favicon: {
            light: "/logo_square.png",
            dark: "/logo_square.png",
            type: "image/png",
        },
    },
}