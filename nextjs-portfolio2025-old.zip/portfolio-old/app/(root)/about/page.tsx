import type { Metadata } from "next";
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MoveRight, Code, Laptop, Sparkles } from "lucide-react"
import Link from "next/link";

export const metadata: Metadata = {
  title: "About",
  description: "Read more about me and my work.",
}

export default function Page() {
  return (
    <section className="my-34 max-w-4xl px-6 pt-10 mx-auto min-w-0 space-y-12 relative">
      {/* Hero */}
      <div className="space-y-6 max-w-3xl">
        <Badge className="shadow-[0_0_12px_rgba(0,0,0,0.15)]">About</Badge>
        <h1 className="text-3xl md:text-5xl font-bold tracking-tight">
          Hey, I’m <span className="text-primary">Fábio Magalhães</span> 👋
        </h1>
        <p className="text-neutral-700 dark:text-neutral-300 text-lg leading-relaxed">
          I build focused, dependable software that feels great to use. My work
          blends engineering precision with product thinking, so every detail
          has a clear purpose.
        </p>
        <div className="flex flex-wrap gap-3">
          <Badge variant="secondary">Software Engineering</Badge>
          <Badge variant="secondary">Problem Solver</Badge>
          <Badge variant="secondary">Product Mindset</Badge>
        </div>
      </div>

      {/* What I do */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="rounded-2xl">
          <CardContent className="p-6 space-y-4">
            <Code className="h-6 w-6" />
            <h3 className="font-semibold text-lg">Build</h3>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Modern web apps with strong fundamentals: performance, clean APIs,
              and systems that scale gracefully.
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardContent className="p-6 space-y-4">
            <Laptop className="h-6 w-6" />
            <h3 className="font-semibold text-lg">Design & UX</h3>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Interfaces that are simple, deliberate, and consistent across every
              screen size.
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardContent className="p-6 space-y-4">
            <Sparkles className="h-6 w-6" />
            <h3 className="font-semibold text-lg">Learn & Improve</h3>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Always iterating, experimenting, and refining the way I work and
              the tools I use.
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-[1.2fr_1fr] gap-6">
        {/* Personal note */}
        <Card className="rounded-2xl">
          <CardContent className="p-8 space-y-4">
            <h2 className="text-xl font-semibold">A bit more about me</h2>
            <p className="text-neutral-700 dark:text-neutral-300 leading-relaxed">
              When I’m not coding, I explore new ideas, improve existing systems,
              and dig into how things work under the hood. I believe good software
              is clarity, reliability, and user trust.
            </p>
            <p className="text-neutral-700 dark:text-neutral-300 leading-relaxed">
              This blog is where I share what I learn, what I build, and the
              lessons I pick up along the way.
            </p>
          </CardContent>
        </Card>

        {/* Skills */}
        <Card className="rounded-2xl">
          <CardContent className="p-8 space-y-5">
            <h2 className="text-xl font-semibold">Skills & Technologies</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <p className="text-sm uppercase tracking-wide text-neutral-500 dark:text-neutral-400">
                  Frontend
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">React</Badge>
                  <Badge variant="secondary">Svelte</Badge>
                  <Badge variant="secondary">Next.js</Badge>
                  <Badge variant="secondary">VueJS</Badge>
                  <Badge variant="secondary">PHP</Badge>
                  <Badge variant="secondary">Angular</Badge>
                  <Badge variant="secondary">JavaScript</Badge>
                  <Badge variant="secondary">HTML</Badge>
                  <Badge variant="secondary">CSS</Badge>
                  <Badge variant="secondary">SCSS</Badge>
                  <Badge variant="secondary">TypeScript</Badge>
                  <Badge variant="secondary">Tailwind CSS</Badge>
                  <Badge variant="secondary">Blazor</Badge>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-sm uppercase tracking-wide text-neutral-500 dark:text-neutral-400">
                  Backend
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Node.js</Badge>
                  <Badge variant="secondary">REST APIs</Badge>
                  <Badge variant="secondary">PostgreSQL</Badge>
                  <Badge variant="secondary">MySQL</Badge>
                  <Badge variant="secondary">MongoDB</Badge>
                  <Badge variant="secondary">C</Badge>
                  <Badge variant="secondary">C++</Badge>
                  <Badge variant="secondary">C#</Badge>
                  <Badge variant="secondary">.NET</Badge>
                  <Badge variant="secondary">Java</Badge>
                  <Badge variant="secondary">Haskell</Badge>
                  <Badge variant="secondary">Python</Badge>
                  <Badge variant="secondary">Go</Badge>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-sm uppercase tracking-wide text-neutral-500 dark:text-neutral-400">
                  Tools
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Docker</Badge>
                  <Badge variant="secondary">Git</Badge>
                  <Badge variant="secondary">Knime</Badge>
                  <Badge variant="secondary">Kubernetes</Badge>
                  <Badge variant="secondary">Figma</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* CTA */}
      <div className="flex justify-start">
        <Link href="/blog">
          <Button size="lg">
            Read the blog <MoveRight className="ml-2" />
          </Button>
        </Link>
      </div>
    </section>
  )
}
