import type { Metadata } from "next";
import { BlogPosts } from '@/components/posts'

export const metadata: Metadata = {
  title: 'Blog',
  description: 'Read my blog.',
}

export default function Page() {
  return (
    <section className='mt-34 max-w-3xl px-6 pt-8 mx-auto min-w-0'>
      <div className="
        absolute inset-0 
        z-20 
        opacity-20 
        mix-blend-overlay 
        pointer-events-none
        bg-no-repeat
          bg-center
          bg-cover
        bg-[url('/square-grid-overlay.png')] 
      "></div>
      <h1 className="font-semibold text-2xl mb-8 tracking-tighter">My Blog</h1>
      <BlogPosts />
    </section>
  )
}