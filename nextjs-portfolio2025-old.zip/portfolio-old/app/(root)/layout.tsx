import Header from '@/components/header';
import Footer from "@/components/footer";
import MouseMovement from "@/components/mouse-movement";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <>
      <MouseMovement />
      <main className="z-10 min-w-0">
        <Header />
        {children}
        <Footer />
      </main>
    </>
  );
}
