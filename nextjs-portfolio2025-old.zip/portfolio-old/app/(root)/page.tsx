import HeroPage from '@/components/sections/hero-page'
import { Marquee } from '@/components/ui/marquee'
import Image from 'next/image';
import HeroProjects from '@/components/sections/hero-projects';
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import Link from 'next/link';
import { MoveRight } from 'lucide-react';
import Config from '@/lib/config';

export default function Home() {
  const IMAGE_SIZE = 42;
  return (
    <main>
      <HeroPage />
      <div className="w-full h-px bg-neutral-800" />
      <Marquee className="z-20 w-full bg-neutral-900/30 py-6" duration={35}>
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/csharp/csharp-original.svg" alt="C#" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-purple-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/cplusplus/cplusplus-original.svg" alt="C++" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 shadow-md drop-shadow-md drop-shadow-blue-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/dotnetcore/dotnetcore-original.svg" alt=".NET" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-purple-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/docker/docker-plain.svg" alt="Docker" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-cyan-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/anaconda/anaconda-original.svg" alt="Anaconda" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-green-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/c/c-original.svg" alt="C" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-gray-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/python/python-original.svg" alt="Python" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-yellow-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/react/react-original.svg" alt="ReactJS" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-cyan-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/java/java-original.svg" alt="Java" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-red-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/javascript/javascript-original.svg" alt="JavaScript" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-yellow-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/vuejs/vuejs-original.svg" alt="VueJS" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-green-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/angular/angular-original.svg" alt="Angular" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-pink-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/mysql/mysql-original-wordmark.svg" alt="MySQL" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-blue-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/mongodb/mongodb-original.svg" alt="MongoDB" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-green-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/typescript/typescript-original.svg" alt="TypeScript" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-blue-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/php/php-original.svg" alt="PHP" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-gray-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/ansible/ansible-original.svg" alt="Ansible" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-neutral-300/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/git/git-original.svg" alt="Git" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-orange-800/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/svelte/svelte-original.svg" alt="Svelte" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-orange-800/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/postgresql/postgresql-original.svg" alt="PostgreSQL" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-blue-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/tailwindcss/tailwindcss-original.svg" alt="TailwindCSS" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-cyan-700/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/blazor/blazor-original.svg" alt="Blazor" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-purple-600/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/lua/lua-original.svg" alt="Lua" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-blue-800/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/haskell/haskell-original.svg" alt="Haskell" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-purple-400/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/nodejs/nodejs-original-wordmark.svg" alt="NodeJS" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-green-700/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/express/express-original.svg" alt="ExpressJS" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-gray-700/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/jquery/jquery-original.svg" alt="jQuery" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-blue-700/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/prolog/prolog-original.svg" alt="Prolog" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-red-400/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/go/go-original-wordmark.svg" alt="Go" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-cyan-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/nextjs/nextjs-original.svg" alt="NextJS" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-gray-700/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/kubernetes/kubernetes-original.svg" alt="Kubernetes" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-blue-600/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/rust/rust-plain.svg" alt="Rust" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-orange-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/django/django-original.svg" alt="Django" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-green-500/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/flutter/flutter-original.svg" alt="Flutter" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-blue-400/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/symfony/symfony-original-wordmark.svg" alt="Symfony" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-gray-400/50" />
        <Image src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/laravel/laravel-original.svg" alt="Laravel" width={IMAGE_SIZE} height={IMAGE_SIZE} className="grayscale hover:filter-none transition-filter duration-300 mx-8 drop-shadow-md drop-shadow-red-500/50" />
      </Marquee>
      <div className="w-full h-px bg-neutral-800" />
      <HeroProjects filteredTags={['boilerplate']} />
      <div className="w-full h-px py-12 mx-auto flex flex-row items-center justify-center">
        <div className="w-4xl h-px border-t border-neutral-800 border-dashed" />
      </div>
      <main className="mb-12 w-full px-6 relative">
        <div className="flex flex-col items-center text-center">
            <Badge className="shadow-[0_0_15px_white] bg-white text-black">
              Get In Touch
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mt-6 max-w-4xl">
              A showcase of my work and passion projects
            </h1>
            <p className="text-lg md:text-xl mt-4 max-w-2xl text-muted-foreground">
              Have any questions or an idea to talk about?
              Feel free to send me an email at
              <a href={`mailto:${Config.profile.email}`} className="ml-1 text-primary hover:underline">
                {Config.profile.email}
              </a>
              .
              I will get back to you as soon as possible. Looking forward to working with you!
            </p>
            <Link href="/about">
              <Button size="lg" className="mt-6">
                See More About Me
                <MoveRight className="ml-2" />
              </Button>
            </Link>
        </div>
      </main>
    </main>
  );
}
