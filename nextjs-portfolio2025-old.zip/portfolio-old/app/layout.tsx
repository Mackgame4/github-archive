import type { Metadata } from "next";
import { Lexend } from "next/font/google";
import { ThemeProvider } from "@/app/provider";
import Config from '@/lib/config';
import "@/app/globals.css";
import { Analytics } from "@vercel/analytics/next";
import { SpeedInsights } from '@vercel/speed-insights/next';

const lexend = Lexend({
  subsets: ["latin"],
  variable: "--font-sans",
});

export const metadata: Metadata = {
  title: Config.title,
  description: Config.description,
  metadataBase: new URL(Config.baseUrl),
};

export default function BaseLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang={Config.lang} suppressHydrationWarning>
      <body className={`${lexend.className} min-h-screen antialiased`}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          {children}
        </ThemeProvider>
        <Analytics />
        <SpeedInsights />
      </body>
    </html>
  );
}
