fx_version 'adamant'
games { 'gta5' }
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

author 'Mackgame4'
description 'A standalone phone resource to FiveM by Mackgame4'
version '1.0.0'

ui_page {
    'html/index.html'
}

files {
	'html/index.html',
	'html/calculator.js',
	'html/calendar.js',
	'html/clock.js',
	'html/images/case.png',
	'html/images/notch.png',
	'html/images/real-case.png',
	'html/images/watermark.png',
	'html/js/app.js',
	'html/js/draggy.js',
	'html/js/apps/appstore.js',
	'html/js/apps/calculator.js',
	'html/js/apps/calendar.js',
	'html/js/apps/clock.js',
	'html/style/icon-stylus.css',
	'html/style/style.css',
	'html/style/apps/calculator.css',
	'html/style/apps/calendar.css',
}

client_scripts {
	'client/main.lua'
}

server_scripts {
	'server/main.lua'
}

exports {
	'OpenPhone',
	'ExitPhone'
}