local debug = true
local isShowing = false
local playerPed = PlayerPedId()

RegisterNetEvent('mack_phone:client:Phone')
AddEventHandler('mack_phone:client:Phone', function(data)
	OpenPhone(data.show)
	ClosePhone(data.show)
	ShowCamera(data.show)
end)

function OpenPhone(show)
	isShowing = true
	SetNuiFocus(true, true)
	SetNuiFocusKeepInput(true)
	SendNUIMessage({
		show = true
	})
	if not IsPedInAnyVehicle(playerPed, false) then
		TaskStartScenarioInPlace(playerPed, 'WORLD_HUMAN_STAND_MOBILE', 0, true)
	end
end

function ExitPhone(show)
	isShowing = false
	SetNuiFocus(false, false)
	SetNuiFocusKeepInput(false)
	SendNUIMessage({
		show = false
	})
	ClearPedTasks(playerPed)
end

function ShowCamera(show)
	isShowing = true
	SetNuiFocus(true, true)
	SetNuiFocusKeepInput(true)
	SendNUIMessage({
		show = true
	})
	if not IsPedInAnyVehicle(playerPed, false) then
		TaskStartScenarioInPlace(playerPed, 'WORLD_HUMAN_STAND_MOBILE', 0, true)
	end
end

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if IsControlJustPressed(0, 288) and isShowing == false then
			exports['mack_phone']:OpenPhone()
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if IsControlJustPressed(0, 202) and isShowing == true then
			exports['mack_phone']:ExitPhone()
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if isShowing then
			DisableControlAction(0, 0,    true) -- CameraSwitch
            DisableControlAction(0, 1,    true) -- LookLeftRight
			DisableControlAction(0, 2,    true) -- LookUpDown
			DisableControlAction(0, 25,   true) -- Input Aim
			DisableControlAction(0, 106,  true) -- Vehicle Mouse Control Override
			DisableControlAction(0, 24,   true) -- Input Attack
			DisableControlAction(0, 140,  true) -- Melee Attack Alternate
			DisableControlAction(0, 141,  true) -- Melee Attack Alternate
			DisableControlAction(0, 142,  true) -- Melee Attack Alternate
			DisableControlAction(0, 257,  true) -- Input Attack 2
			DisableControlAction(0, 263,  true) -- Input Melee Attack
			DisableControlAction(0, 264,  true) -- Input Melee Attack 2
			DisableControlAction(0, 12,   true) -- Weapon Wheel Up Down
			DisableControlAction(0, 14,   true) -- Weapon Wheel Next
			DisableControlAction(0, 15,   true) -- Weapon Wheel Prev
			DisableControlAction(0, 16,   true) -- Select Next Weapon
			DisableControlAction(0, 17,   true) -- Select Prev Weapon
        end
    end
end)

RegisterCommand("cam", function(source , args, rawCommand)
	if debug then
		SetFollowPedCamViewMode(4)
	end
end)

RegisterCommand("phone", function(source , args, rawCommand)
	if debug then
		exports['mack_phone']:OpenPhone()
	end
end)

RegisterCommand("closephone", function(source , args, rawCommand)
	if debug then
		exports['mack_phone']:ExitPhone()
	end
end)