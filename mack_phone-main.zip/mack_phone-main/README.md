# mack_phone  

## ⚙️ How to Install  
- Download mack_phone (https://github.com/Mackgame4/mack_phone) and drop in your "resources" folder  
- Add to your server.cfg, the following line: `ensure mack_phone`  
- Just start your server and have fun  

## 📷 Screenshots  
Screenshot: comig soon  
Video: https://streamable.com/oz9jbs  

## ☁️ Download:  
Here or Github (https://github.com/Mackgame4/mack_phone)  
Join our [Discord](https://discord.io/mack) or in (https://discord.io/mack)  

## 🔖 Attention:  
### License:  
mack_phone license its based on *GNU Public License 3.0* with some minor changes, with one in special:  
#### DO NOT RE-RELEASE WITHOU PERMITION, ONLY SHARE THE OFFICIAL REPOSITORY AND COSTUMIZE TO YOUR-SELF
