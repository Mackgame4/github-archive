var appmodal = '<div id="calculator" class="modal">'+
'    <img src="images/notch.png" class="notch"></img>'+
'      <span id="calculator-close" class="close"></span>'+
'      <div class="calculator-app">'+
'        <div class="screen"></div>'+
'        <div class="buttons">'+
'          <div class="operators">'+
'            <button data-val="÷">÷</button>'+
'            <button data-val="x">x</button>'+
'            <button data-val="-">-</button>'+
'            <button data-val="+">+</button>'+
'            <button data-val="=">=</button>'+
'          </div>'+
'          <div class="numbers">'+
'            <button data-val="9">9</button>'+
'            <button data-val="8">8</button>'+
'            <button data-val="7">7</button>'+
'            <button data-val="6">6</button>'+
'            <button data-val="5">5</button>'+
'            <button data-val="4">4</button>'+
'            <button data-val="3">3</button>'+
'            <button data-val="2">2</button>'+
'            <button data-val="1">1</button>'+
'            <button data-val="0" href="0">0</button>'+
'            <button data-val=".">.</button>'+
'            <button data-val="clear">C</button>'+
'          </div>'+
'        </div>'+
'      </div>'+
'  </div>';

document.write(appmodal)