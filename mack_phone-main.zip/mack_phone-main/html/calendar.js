
var appmodal = '<div id="calendar" class="modal">'+
'    <img src="images/notch.png" class="notch"></img>'+
'    <div id="calendar-close" class="close"></div>'+
'    <!--span class="month" id="js-month"></span><span>-</span--><span class="month-text" id="js-month-text">Month</span><span class="year-text" id="js-year-text">Year</span>'+
'      <div class="calendar-conatiner">'+
'        <table class="calendar-table">'+
'          <thead>'+
'            <tr><th>S</th><th>M</th><th>T</th><th>W</th><th>T</th><th>F</th><th>S</th></tr>'+
'          </thead>'+
'          <tbody id="js-calendar"></tbody>'+
'        </table>'+
'      </div>'+
'  </div>';

document.write(appmodal)