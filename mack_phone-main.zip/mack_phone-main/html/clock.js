
var appmodal = '<div id="clock" class="modal">'+
'    <img src="images/notch.png" class="notch"></img>'+
'    <div id="clock-close" class="close"></div>'+
'    <nav class="controls">'+
'			<button id="clock-start" onClick="stopwatch.start();">Start</button>'+
'			<button id="clock-lap" onClick="stopwatch.lap();">Lap</button>'+
'			<button id="clock-stop" onClick="stopwatch.stop();">Stop</button>'+
'			<button id="clock-clear" onClick="stopwatch.clear();">Clear</button>'+
'		</nav>'+
'		<div class="stopwatch"></div>'+
'		<div class="results"></div>'+
'  </div>';

document.write(appmodal)