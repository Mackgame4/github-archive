/* calendar built with the tutorial from https://liginc.co.jp/355474 */
var $window = $(window);
var $month = $('#js-month');
var $monthText = $('#js-month-text');
var $yearText = $('#js-year-text');
var $tbody = $('#js-calendar');

var today = new Date();
var currentYear = today.getFullYear(),
    currentMonth = today.getMonth();

$window.on('load',function(){
  calendarHeading(currentYear, currentMonth);
  calendarBody(currentYear, currentMonth, today);
});

function calendarBody(year, month, today){
  var todayYMFlag = today.getFullYear() === year && today.getMonth() === month ? true : false;
  var startDate = new Date(year, month, 1);
  var endDate  = new Date(year, month + 1 , 0);
  var startDay = startDate.getDay();
  var endDay = endDate.getDate();
  var textSkip = true;
  var textDate = 1;
  var tableTd ='';
  var tableBody ='';
  
  for (var row = 0; row < 6; row++){
    var tr = '<tr>';
    
    for (var col = 0; col < 7; col++) {
      if (row === 0 && startDay === col){
        textSkip = false;
      }
      if (textDate > endDay) {
        textSkip = true;
      }
      var addClass = todayYMFlag && textDate === today.getDate() && !textSkip ? 'is-today' : '';
      var textTd = textSkip ? '&nbsp;' : textDate++;
      var td = '<td class="'+addClass+'"><p>'+textTd+'</p></td>';
      tr += td;
    }
    tr += '</tr>';
    tableBody += tr;
  }
  $tbody.html(tableBody);
}

function pad(val) {
  var valString = val + "";
  if (valString.length < 2) {
    return "0" + valString;
  } else {
    return valString;
  }
}

function calendarHeading(year, month){
  if (month+1 == 1) {
    $monthText.text("January");
  } if (month+1 == 2) {
    $monthText.text("February");
  } if (month+1 == 3) {
    $monthText.text("March");
  } if (month+1 == 4) {
    $monthText.text("April");
  } if (month+1 == 5) {
    $monthText.text("May");
  } if (month+1 == 6) {
    $monthText.text("June");
  } if (month+1 == 7) {
    $monthText.text("July");
  } if (month+1 == 8) {
    $monthText.text("August");
  } if (month+1 == 9) {
    $monthText.text("September");
  } if (month+1 == 10) {
    $monthText.text("October");
  } if (month+1 == 11) {
    $monthText.text("November");
  } if (month+1 == 12) {
    $monthText.text("December");
  }
  $yearText.text(year);
  //$month.text(month+1);
}