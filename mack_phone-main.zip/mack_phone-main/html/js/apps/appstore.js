var d = new Date();
var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
document.getElementById("appstore-day").innerHTML = days[d.getDay()];
document.getElementById("appstore-month").innerHTML = months[d.getMonth()];
document.getElementById("appstore-date").innerHTML = d.getDate();

function installTwitter() {
    $('.grid')
    .find('li:eq(19)') // li position to modify
    .removeClass("removable");
    document.getElementById("twitter-app").style = "background-image: url('https://i.pinimg.com/originals/04/52/ac/0452ac38302c16481666342d3d532c96.png');";
    document.getElementById("twitterapp-ibutton").style = "display: none;";
    document.getElementById("twitterapp-ubutton").style = "display: block;";
}

function uninstallTwitter() {
  $('.grid')
  .find('li:eq(19)') // li position to modify
  .addClass("removable");
  document.getElementById("twitter-app").style = "background-image: none;";
  document.getElementById("twitterapp-ibutton").style = "display: block;";
  document.getElementById("twitterapp-ubutton").style = "display: none;";
}

function installCalculator() {
  $('.grid')
  .find('li:eq(18)') // li position to modify
  .removeClass("removable");
  document.getElementById("calculator-app").style = "background-image: url('https://www.briomedia.co.uk/wp-content/uploads/2017/08/Icons-03.png');";
  document.getElementById("calculatorapp-ibutton").style = "display: none;";
  document.getElementById("calculatorapp-ubutton").style = "display: block;";
}

function uninstallCalculator() {
$('.grid')
.find('li:eq(18)') // li position to modify
.addClass("removable");
document.getElementById("calculator-app").style = "background-image: none;";
document.getElementById("calculatorapp-ibutton").style = "display: block;";
document.getElementById("calculatorapp-ubutton").style = "display: none;";
}