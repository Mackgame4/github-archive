// Fivem NUI
window.addEventListener('message', function (event) {
  OpenPhone(event.data);
});

function OpenPhone(data) {
  if (data.show == true) {
    document.getElementById('phone').style = 'display: block;';
  } else {
    document.getElementById('phone').style = 'display: none;';
  }
}

// Hours div
function tick() {
  var epoch = Date.now();
  var datetime = new Date(epoch);
  var hour    = datetime.getHours();
  var minute  = datetime.getMinutes();
  document.querySelector("#hours").innerHTML = hour + ":" + addZero(minute) + `&nbsp;&nbsp;<i class="fas fa-location-arrow"></i>`;      
}

function addZero(i) {
  if (i < 10) {
    i = "0" + i
  };  
  return i;
}
  
setInterval(tick, 1000);

// AppStore
function appstore() {
  var app = "appstore";
  var modal = document.getElementById(app);
  var close = document.getElementById(app+"-close");
  modal.style.display = "block";
  close.onclick = function() {
    modal.style.display = "none";
  }
}

// Calculator
function calculator() {
  var app = "calculator";
  var modal = document.getElementById(app);
  var close = document.getElementById(app+"-close");
  modal.style.display = "block";
  close.onclick = function() {
    modal.style.display = "none";
  }
}

// Calendar
function calendar() {
  var app = "calendar";
  var modal = document.getElementById(app);
  var close = document.getElementById(app+"-close");
  modal.style.display = "block";
  close.onclick = function() {
    modal.style.display = "none";
  }
}

// Clock
function clock() {
  var app = "clock";
  var modal = document.getElementById(app);
  var close = document.getElementById(app+"-close");
  modal.style.display = "block";
  close.onclick = function() {
    modal.style.display = "none";
  }
}

// Notes
function notes() {
  var app = "notes";
  var modal = document.getElementById(app);
  var close = document.getElementById(app+"-close");
  modal.style.display = "block";
  close.onclick = function() {
    modal.style.display = "none";
  }
}

function notesList() {
  var app = "notesList";
  var modal = document.getElementById(app);
  var close = document.getElementById(app+"-close");
  modal.style.display = "block";
  close.onclick = function() {
    modal.style.display = "none";
  }
}

function notesLastDate() {
  var date = new Date();
  x = document.getElementsByClassName("lastDate");
  x[0].innerHTML = date.toDateString();
}

function openNote() {
  notesLastDate();
  console.log("click");
}

// Camera
function camera() {
  var cameraOn = document.getElementById("watermark");
  if (cameraOn.style.display === "none") {
    cameraOn.style.display = "block";
    document.getElementById('phone').style = 'display: none;';
  } else {
    cameraOn.style.display = "none";
    document.getElementById('phone').style = 'display: block;';
  }
}