import type { Metadata } from "next";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  MoveRight,
  Code,
  Laptop,
  Sparkles,
  Linkedin,
  Github,
  ArrowUpRight,
  ChevronDown,
  BriefcaseBusiness,
  GraduationCap,
} from "lucide-react";
import Link from "next/link";
import Config from "@/lib/config";

export const metadata: Metadata = {
  title: "About",
  description: "Read more about me and my work.",
};

export default function Page() {
  return (
    <section className="relative mx-auto mt-34 mb-18 max-w-5xl space-y-12 px-6 pt-10">
      {/* Hero */}
      <div className="grid items-center gap-8 overflow-hidden md:grid-cols-[minmax(0,1fr)_14rem]">
        <div className="space-y-5">
          <h1 className="max-w-2xl text-4xl font-bold leading-tight tracking-tight md:text-6xl">
            Hey, I&apos;m{" "}
            <span className="block text-primary">Fábio Magalhães 👋</span>
          </h1>
          <p className="max-w-2xl text-base leading-7 text-neutral-700 dark:text-neutral-300 md:text-lg">
            I build focused, dependable software that feels great to use. My work
            blends engineering precision with product thinking, so every detail
            has a clear purpose.
          </p>
          <div className="flex flex-wrap gap-3">
            <Badge variant="secondary">Software Engineering</Badge>
            <Badge variant="secondary">Problem Solver</Badge>
          </div>
        </div>
        <img
          src="/profilepicture.png"
          alt="Fábio Magalhães"
          className="h-52 w-full max-w-64 justify-self-center rounded-2xl object-cover shadow-lg md:h-64 md:w-56 border-4 border-muted"
        />
      </div>

      {/* What I do */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="rounded-2xl">
          <CardContent className="space-y-4 p-6">
            <Code className="h-6 w-6" />
            <h3 className="text-lg font-semibold">Build</h3>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Modern web apps with strong fundamentals: performance, clean APIs,
              and systems that scale gracefully.
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardContent className="space-y-4 p-6">
            <Laptop className="h-6 w-6" />
            <h3 className="text-lg font-semibold">Design & UX</h3>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Interfaces that are simple, deliberate, and consistent across every
              screen size.
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardContent className="space-y-4 p-6">
            <Sparkles className="h-6 w-6" />
            <h3 className="text-lg font-semibold">Learn & Improve</h3>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Always iterating, experimenting, and refining the way I work and
              the tools I use.
            </p>
          </CardContent>
        </Card>
      </div>

      <Card id="experience-education" className="rounded-2xl">
        <CardContent className="p-0">
          <div className="border-b px-8 py-6">
            <h2 className="text-2xl font-semibold tracking-tight">Experience & Education</h2>
            <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
              A quick view of the practical work and academic foundation behind my projects.
            </p>
          </div>

          <div className="grid gap-0 lg:grid-cols-2">
            <div className="space-y-6 px-8 py-7 lg:border-r">
              <div className="flex items-center gap-3">
                <span className="flex size-9 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
                  <BriefcaseBusiness className="size-4" />
                </span>
                <h3 className="text-lg font-semibold">Work Experience</h3>
              </div>
              <div className="grid gap-6">
                {Config.resume.workExperience.map((work) => (
                  <details key={work.company} className="group grid gap-2">
                    <summary className="flex cursor-pointer list-none items-center justify-between gap-x-3 rounded-lg transition-colors hover:text-primary">
                      <div className="flex min-w-0 flex-1 items-center gap-x-3">
                        <img
                          src={work.logoUrl}
                          alt={work.company}
                          className="size-9 flex-none overflow-hidden rounded-full border object-contain p-1 shadow-sm ring-2 ring-border/60"
                        />
                        <div className="flex min-w-0 flex-1 flex-col gap-1">
                          <div className="flex items-center gap-2 font-semibold leading-none">
                            {work.company}
                            <ChevronDown
                              className="h-3.5 w-3.5 text-muted-foreground opacity-0 transition-all duration-200 group-hover:opacity-100 group-open:rotate-180 group-open:opacity-100"
                              aria-hidden
                            />
                          </div>
                          <div className="font-sans text-sm text-muted-foreground">
                            {work.title}
                          </div>
                        </div>
                      </div>
                      <div className="flex-none text-right text-xs tabular-nums text-muted-foreground">
                        {work.start} - {work.end}
                      </div>
                    </summary>
                    <p className="ml-12 text-sm leading-6 text-muted-foreground">
                      {work.description}
                    </p>
                  </details>
                ))}
              </div>
            </div>

            <div className="space-y-6 border-t px-8 py-7 lg:border-t-0">
              <div className="flex items-center gap-3">
                <span className="flex size-9 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
                  <GraduationCap className="size-4" />
                </span>
                <h3 className="text-lg font-semibold">Education</h3>
              </div>
              <div className="flex flex-col gap-6">
                {Config.resume.education.map((item) => (
                  <Link
                    key={item.school}
                    href={item.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center justify-between gap-x-3 rounded-lg transition-colors hover:text-primary"
                  >
                    <div className="flex min-w-0 flex-1 items-center gap-x-3">
                      <img
                        src={item.logoUrl}
                        alt={item.school}
                        className="size-9 flex-none overflow-hidden rounded-full border object-contain p-1 shadow-sm ring-2 ring-border/60"
                      />
                      <div className="flex min-w-0 flex-1 flex-col gap-1">
                        <div className="flex items-center gap-2 font-semibold leading-none">
                          {item.school}
                          <ArrowUpRight
                            className="h-3.5 w-3.5 -translate-x-2 text-muted-foreground opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:opacity-100"
                            aria-hidden
                          />
                        </div>
                        <div className="font-sans text-sm text-muted-foreground">
                          {item.degree}
                        </div>
                      </div>
                    </div>
                    <div className="flex-none text-right text-xs tabular-nums text-muted-foreground">
                      {item.start} - {item.end}
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        {/* Personal note */}
        <Card className="rounded-2xl">
          <CardContent className="space-y-4 p-8">
            <h2 className="text-xl font-semibold">A bit more about me</h2>
            <p className="leading-relaxed text-neutral-700 dark:text-neutral-300">
              When I&apos;m not coding, I explore new ideas, improve existing systems,
              and dig into how things work under the hood. I believe good software
              is clarity, reliability, and user trust.
            </p>
            <p className="leading-relaxed text-neutral-700 dark:text-neutral-300">
              This blog is where I share what I learn, what I build, and the
              lessons I pick up along the way.
            </p>
            <h2 className="text-xl font-semibold">Academic Background</h2>
            <p className="leading-relaxed text-neutral-700 dark:text-neutral-300">
              I hold a Bachelor in Software Engineering from the University of
              Minho, where I developed a strong foundation in algorithms, data
              structures, and software design principles. My academic journey has
              equipped me with the skills and knowledge to tackle complex software
              engineering challenges and continuously learn new technologies.
            </p>
          </CardContent>
        </Card>

        {/* Skills */}
        <Card className="rounded-2xl">
          <CardContent className="space-y-5 p-8">
            <h2 className="text-xl font-semibold">Skills & Technologies</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <p className="text-sm uppercase text-neutral-500 dark:text-neutral-400">
                  Frontend
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">React</Badge>
                  <Badge variant="secondary">Svelte</Badge>
                  <Badge variant="secondary">Next.js</Badge>
                  <Badge variant="secondary">VueJS</Badge>
                  <Badge variant="secondary">PHP</Badge>
                  <Badge variant="secondary">Angular</Badge>
                  <Badge variant="secondary">JavaScript</Badge>
                  <Badge variant="secondary">HTML</Badge>
                  <Badge variant="secondary">CSS</Badge>
                  <Badge variant="secondary">SCSS</Badge>
                  <Badge variant="secondary">TypeScript</Badge>
                  <Badge variant="secondary">Tailwind CSS</Badge>
                  <Badge variant="secondary">Blazor</Badge>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-sm uppercase text-neutral-500 dark:text-neutral-400">
                  Backend
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Node.js</Badge>
                  <Badge variant="secondary">REST APIs</Badge>
                  <Badge variant="secondary">PostgreSQL</Badge>
                  <Badge variant="secondary">MySQL</Badge>
                  <Badge variant="secondary">MongoDB</Badge>
                  <Badge variant="secondary">C</Badge>
                  <Badge variant="secondary">C++</Badge>
                  <Badge variant="secondary">C#</Badge>
                  <Badge variant="secondary">.NET</Badge>
                  <Badge variant="secondary">Java</Badge>
                  <Badge variant="secondary">Haskell</Badge>
                  <Badge variant="secondary">Python</Badge>
                  <Badge variant="secondary">Go</Badge>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-sm uppercase text-neutral-500 dark:text-neutral-400">
                  Tools
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Docker</Badge>
                  <Badge variant="secondary">Git</Badge>
                  <Badge variant="secondary">Knime</Badge>
                  <Badge variant="secondary">Kubernetes</Badge>
                  <Badge variant="secondary">Figma</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* CTA */}
      <div className="flex flex-wrap gap-3">
        <Link href="/blog">
          <Button size="lg">
            Read the blog <MoveRight className="ml-2" />
          </Button>
        </Link>
        <Link
          href={Config.profile.socials.linkedin.url}
          target="_blank"
          rel="noopener noreferrer"
        >
          <Button size="lg" variant="outline">
            <Linkedin className="mr-2 h-5 w-5" />
            LinkedIn
          </Button>
        </Link>
        <Link
          href={Config.profile.socials.github.url}
          target="_blank"
          rel="noopener noreferrer"
        >
          <Button size="lg" variant="outline">
            <Github className="mr-2 h-5 w-5" />
            GitHub
          </Button>
        </Link>
      </div>
    </section>
  );
}
