import type { Metadata } from "next";
import { BlogPosts } from '@/components/posts'
import { Button } from "@/components/ui/button";
import { MoveRight, Linkedin, Github } from "lucide-react";
import Link from "next/link";
import Config from "@/lib/config";

export const metadata: Metadata = {
  title: 'Blog',
  description: 'Read my blog.',
}

export default function Page() {
  return (
    <section className='mt-34 mb-18 max-w-3xl px-6 pt-8 mx-auto min-w-0'>
      <div className="
        absolute inset-0 
        z-20 
        opacity-20 
        mix-blend-overlay 
        pointer-events-none
        bg-no-repeat
          bg-center
          bg-cover
        bg-[url('/square-grid-overlay.png')] 
      "></div>
      <h1 className="font-semibold text-2xl mb-8 tracking-tighter">My Blog</h1>
      <BlogPosts />
      <div className="mt-12 flex flex-col items-start gap-4 border-t border-neutral-200 pt-8 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-semibold tracking-tight">
            Wanna know more about myself?
          </h2>
          <p className="mt-2 text-neutral-600 dark:text-neutral-400">
            Read more about my background, experience, and the tools I work with.
          </p>
        </div>
        <div className="flex flex-wrap gap-3">
          <Link href="/about">
            <Button>
              About me
              <MoveRight className="ml-2" />
            </Button>
          </Link>
          <Link
            href={Config.profile.socials.linkedin.url}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button size="lg" variant="outline">
              <Linkedin className="mr-2 h-5 w-5" />
              LinkedIn
            </Button>
          </Link>
          <Link
            href={Config.profile.socials.github.url}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button size="lg" variant="outline">
              <Github className="mr-2 h-5 w-5" />
              GitHub
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
