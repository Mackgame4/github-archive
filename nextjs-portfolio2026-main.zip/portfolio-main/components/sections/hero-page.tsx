import ThreeComputer from '@/components/3d/three-computer';

export default function HeroPage() {
    return (
        <main className='relative pt-24 h-screen w-full overflow-hidden'>
            <div className="
                absolute inset-0 
                -z-10 
                opacity-20 
                pointer-events-none
                bg-[url('/square-grid-overlay.png')] 
            "></div>

            <section className='relative z-10 h-full w-full flex items-center'>
                <div className='mx-auto h-full w-full max-w-7xl px-6 md:px-10'>
                    <div className='relative h-full flex items-center'>
                        <div className='absolute inset-0 -z-10 opacity-35 md:hidden'>
                            <ThreeComputer />
                        </div>

                        <div className='hidden md:block w-1/2 h-full'>
                            <ThreeComputer />
                        </div>

                        <div className='w-full md:w-1/2 text-right'>
                            <h1 className='text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight'>
                                Hi, I&apos;m Fábio. 👋
                            </h1>
                            <p className='mt-4 text-lg sm:text-xl md:text-2xl text-muted-foreground'>
                                Software engineer focused on building reliable systems, beautiful interfaces, and practical digital experiences that solve real-world problems.
                            </p>
                            <div className='mt-10 flex flex-col items-center gap-2 text-sm text-muted-foreground'>
                                <span>Scroll</span>
                                <div className='relative h-10 w-6 rounded-full border border-muted-foreground/60'>
                                    <div className='scroll-dot absolute left-1/2 h-2 w-2 -translate-x-1/2 rounded-full bg-muted-foreground/80' />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    );
}