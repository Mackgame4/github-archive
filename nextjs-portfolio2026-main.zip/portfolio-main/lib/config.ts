export default {
    baseUrl: process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000',
    lang: 'en',
    title: 'CodeWithFab - Portfolio',
    description: 'A personal portfolio featuring my projects, technical blog posts, and hands-on experiments in development.',

    navItems: [
        { name: 'Home', path: '/' },
        { name: 'Blog', path: '/blog' },
        { name: 'About', path: '/about' }
    ],

    profile: {
        name: "Fab.Magalhães",
        badge: "Software Engineer",
        email: "fabiomagalhaes454@hotmail.com",
        address: "Braga, Portugal",
        socials: {
            linkedin: { url: "https://www.linkedin.com/in/fabiomagalhaes104365/", handle: "@fabiomagalhaes104365" },
            github: { url: "https://github.com/Mackgame4", handle: "@mackgame4" },
            twitch: { url: "https://www.twitch.tv/mackgame4", handle: "@mackgame4" },
        },
    },

    headerLinks: [
        { name: 'LinkedIn', url: "https://www.linkedin.com/in/fabiomagalhaes104365/" },
        { name: 'GitHub', url: "https://github.com/Mackgame4" }
    ],

    resume: {
        workExperience: [
            {
                company: "Project Work",
                title: "Software Engineering Projects",
                logoUrl: "/logo_badge.png",
                start: "2020",
                end: "Present",
                description: "Built academic and personal projects across web development, distributed systems, compilers, scheduling tools, games, secure file services, and data-oriented applications.",
            },
        ],
        education: [
            {
                school: "University of Minho",
                href: "https://www.uminho.pt",
                degree: "Bachelor in Software Engineering",
                logoUrl: "/logo_badge.png",
                start: "2020",
                end: "2024",
            },
        ],
    },

    assets: {
        badgeLogo: {
            light: "/logo_badge.png",
            dark: "/logo_badge.png",
            type: "image/png",
        },
        favicon: {
            light: "/logo_square.png",
            dark: "/logo_square.png",
            type: "image/png",
        },
    },
}
