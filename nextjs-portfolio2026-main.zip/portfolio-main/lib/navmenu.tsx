import { Home, FolderOpen, User } from 'lucide-react';

export const navItems = [
    { name: 'Home', path: '/', icon: <Home /> },
    { name: 'Blog', path: '/blog', icon: <FolderOpen /> },
    { name: 'About', path: '/about', icon: <User /> }
];

export const navLinks = [
    { name: 'Home', url: '/' },
];