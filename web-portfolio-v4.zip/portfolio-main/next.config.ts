import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: ['next-mdx-remote'],
  experimental: {
    cssChunking: true,
    viewTransition: true,
  },
};

export default nextConfig;
