export default {
    baseUrl: process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000',
    lang: 'en',
    title: 'CodeWithFab - Portfolio',
    description: 'A personal portfolio featuring my projects, technical blog posts, and hands-on experiments in development.',
    github: 'https://github.com/Mackgame4',
    linkedin: 'https://www.linkedin.com/in/fabiomagalhaes104365/',
}