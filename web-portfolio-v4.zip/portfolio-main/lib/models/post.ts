type PostMetadata = {
    title?: string;
    publishedAt?: string;
    summary?: string;
    color?: string;
    cover?: string;
    team?: string[];
    techStack?: string[];
    tags?: string[];
}