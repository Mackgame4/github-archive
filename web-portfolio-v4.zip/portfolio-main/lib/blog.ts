import 'server-only'; // almost a "use server" directive but without saying its server actions
import fs, { type PathLike } from 'fs';
import path from 'path';

type BlogMetadata = PostMetadata & Record<string, string | string[]>;

function parseFrontmatter(fileContent: string) {
    const frontmatterRegex = /---\s*([\s\S]*?)\s*---/;
    const match = frontmatterRegex.exec(fileContent);
    const frontMatterBlock = match![1];
    const content = fileContent.replace(frontmatterRegex, '').trim();
    const frontMatterLines = frontMatterBlock.trim().split('\n');
    let metadata: BlogMetadata = {};
    for (let i = 0; i < frontMatterLines.length; i++) {
        let line = frontMatterLines[i].trim();
        if (!line) continue;
        if (line.includes(':')) {
            const [key, ...valueArr] = line.split(':');
            const keyTrimmed = key.trim() as keyof BlogMetadata;
            const value = valueArr.join(':').trim();
            if (value === '') {
                // Handle arrays
                let arr: string[] = [];
                while (frontMatterLines[i + 1] && frontMatterLines[i + 1].trim().startsWith('-')) {
                    arr.push(frontMatterLines[i + 1].trim().replace(/^-\s*/, ''));
                    i++;
                }
                metadata[keyTrimmed] = arr;
            } else {
                metadata[keyTrimmed] = value.replace(/^['"](.*)['"]$/, '$1');
            }
        }
    }
    return { metadata, content };
}

function getMDXFiles(dir: PathLike) {
    return fs.readdirSync(dir).filter((file) => path.extname(file) === '.mdx');
}

function readMDXFile(filePath: PathLike) {
    const rawContent = fs.readFileSync(filePath, 'utf-8');
    return parseFrontmatter(rawContent);
}

function getMDXData(dir: PathLike) {
    const mdxFiles = getMDXFiles(dir);
    return mdxFiles.map((file) => {
        const { metadata, content } = readMDXFile(path.join(dir as string, file));
        const slug = path.basename(file, path.extname(file));
        return { metadata, slug, content };
    });
}

export function getBlogPosts() {
    return getMDXData(path.join(process.cwd(), '_posts'));
}

export function formatDate(date: string, includeRelative = false) {
    const currentDate = new Date();
    if (!date.includes('T')) {
        date = `${date}T00:00:00`;
    }
    const targetDate = new Date(date);
    const yearsAgo = currentDate.getFullYear() - targetDate.getFullYear();
    const monthsAgo = currentDate.getMonth() - targetDate.getMonth();
    const daysAgo = currentDate.getDate() - targetDate.getDate();
    let formattedDate = '';
    if (yearsAgo > 0) {
        formattedDate = `${yearsAgo}y ago`;
    } else if (monthsAgo > 0) {
        formattedDate = `${monthsAgo}mo ago`;
    } else if (daysAgo > 0) {
        formattedDate = `${daysAgo}d ago`;
    } else {
        formattedDate = 'Today';
    }
    const fullDate = targetDate.toLocaleString('en-us', {
        month: 'long',
        day: 'numeric',
        year: 'numeric'
    });
    if (!includeRelative) {
        return fullDate;
    }
    return `${fullDate} (${formattedDate})`;
}