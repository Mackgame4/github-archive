import { MDXRemote, MDXRemoteProps } from 'next-mdx-remote/rsc';
import React from 'react';

import * as MDXComponents from './mdx-components';

export function slugify(str: React.ReactNode): string {
  return str!
    .toString()
    .toLowerCase()
    .trim() // Remove whitespace from both ends of a string
    .replace(/\s+/g, '-') // Replace spaces with -
    .replace(/&/g, '-and-') // Replace & with 'and'
    .replace(/[^\w\-]+/g, '') // Remove all non-word characters except for -
    .replace(/\-\-+/g, '-') // Replace multiple - with single -
}

export function createHeading(level: number) {
  const Heading = ({ children }: { children: React.ReactNode }) => {
    const slug = slugify(children);
    return React.createElement(
      `h${level}`,
      { id: slug },
      [
        React.createElement('a', {
          href: `#${slug}`,
          key: `link-${slug}`,
          className: 'anchor',
        }),
      ],
      children
    );
  }
  Heading.displayName = `Heading${level}`;
  return Heading;
}

const components = {
  h1: createHeading(1),
  h2: createHeading(2),
  h3: createHeading(3),
  h4: createHeading(4),
  h5: createHeading(5),
  h6: createHeading(6),
  Image: MDXComponents.RoundedImage,
  Divider: MDXComponents.Divider,
  HighlightCard: MDXComponents.HighlightCard,
  Iteractive: MDXComponents.Iteractive,
  Video: MDXComponents.Video,
  Link: MDXComponents.CustomLink,
  Context: MDXComponents.ContextSection,
  Alert: MDXComponents.AlertComponent,
  Accordion: MDXComponents.Accordion,
  AccordionItem: MDXComponents.AccordionItem,
  a: MDXComponents.CustomLink,
  code: MDXComponents.Code,
}

export function CustomMDX(props: MDXRemoteProps) {
  return (
    <MDXRemote
      {...props}
      components={{ ...components, ...(props.components || {}) }}
    />
  )
}