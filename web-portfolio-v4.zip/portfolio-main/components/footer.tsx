import { Rss, Github, Linkedin } from 'lucide-react';
import Link from 'next/link';
import Config from '@/lib/config';

export default function Footer() {
    return (
        <footer className="mb-16 flex flex-col">
            <div className="font-sm mt-8 flex flex-col items-start justify-start space-x-0 space-y-2 text-neutral-600 md:flex-row md:space-x-4 md:space-y-0 dark:text-neutral-300">
                <Link className="flex items-center justify-center transition-all hover:text-neutral-800 dark:hover:text-neutral-100" href="/rss">
                    <Rss className='h-5 w-5'/>
                    <span className="ml-2 h-7">RSS</span>
                </Link>
                <Link className="flex items-center justify-center transition-all hover:text-neutral-800 dark:hover:text-neutral-100" rel="noopener noreferrer" target="_blank" href={Config.github}>
                    <Github className='h-5 w-5'/>
                    <span className="ml-2 h-7">Github</span>
                </Link>
                <Link className="flex items-center justify-center transition-all hover:text-neutral-800 dark:hover:text-neutral-100" rel="noopener noreferrer" target="_blank" href={Config.linkedin}>
                    <Linkedin className='h-5 w-5 mb-1'/>
                    <span className="ml-2 h-7">Linkedin</span>
                </Link>
            </div>
            <p className="mt-8 text-neutral-600 dark:text-neutral-300">
                &copy; {new Date().getFullYear()} MIT Licensed - Last updated: {new Date().toLocaleDateString()}
            </p>
        </footer>
    )
}