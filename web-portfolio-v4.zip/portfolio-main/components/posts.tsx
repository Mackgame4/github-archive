import Link from 'next/link';
import { ViewTransition } from 'react';

import { formatDate, getBlogPosts } from '@/lib/blog';

export function BlogPosts() {
    const blogPosts = getBlogPosts().sort((a, b) => {
        if (new Date(a.metadata.publishedAt!) > new Date(b.metadata.publishedAt!)) {
            return -1;
        }
        return 1;
    });
    return (
        <>
        {blogPosts.map((post) => (
            <Link key={post.slug} className="flex flex-col space-y-1 mb-4" href={`/blog/${post.slug}`}>
                <div className="w-full flex flex-col md:flex-row space-x-0 md:space-x-2">
                    <ViewTransition name={`post-date-${post.slug}`}>
                        <span className="text-neutral-600 dark:text-neutral-400 w-25 tabular-nums">
                            {formatDate(post.metadata.publishedAt!, false)}
                        </span>
                    </ViewTransition>
                    <ViewTransition name={`post-title-${post.slug}`}>
                        <h2 className="text-neutral-900 dark:text-neutral-100 tracking-tight">
                            {post.metadata.title}
                        </h2>
                    </ViewTransition>
                </div>
            </Link>
        ))}
        </>
    )
}