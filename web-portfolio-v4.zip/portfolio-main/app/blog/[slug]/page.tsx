import { notFound } from 'next/navigation'
import { CustomMDX } from '@/components/mdx-render'
import { formatDate, getBlogPosts } from '@/lib/blog'
import Config from '@/lib/config'
import { Safari } from '@/components/ui/mockup'
import { ViewTransition } from 'react'

export async function generateStaticParams() {
  let posts = getBlogPosts()

  return posts.map((post) => ({
    slug: post.slug,
  }))
}

export async function generateMetadata({ params }: any) {
    const { slug } = await params
  let post = getBlogPosts().find((post) => post.slug === slug)
  if (!post) {
    return
  }

  let {
    title,
    publishedAt: publishedTime,
    summary: description,
    cover,
  } = post.metadata
  let ogImage = cover
    ? cover
    : `${Config.baseUrl}/og?title=${encodeURIComponent(title!)}`

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      type: 'article',
      publishedTime,
      url: `${Config.baseUrl}/blog/${post.slug}`,
      images: [
        {
          url: ogImage,
        },
      ],
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: [ogImage],
    },
  }
}

export default async function Blog({ params }: any) {
    const { slug } = await params
  let post = getBlogPosts().find((post) => post.slug === slug)

  type TeamMember = {
    name: string
    url?: string
    role?: string
  }

  const parseTeam = (team?: string[]): TeamMember[] => {
    if (!team || team.length === 0) return [{ name: "Solo Project" }]

    return team.map((memberStr) => {
      // Regex: Name [url] (role)
      const regex = /^(.*?)\s*(?:\[(.*?)\])?\s*(?:\((.*?)\))?$/
      const match = memberStr.match(regex)

      if (!match) {
        return { name: memberStr.trim() }
      }

      const [, name, url, role] = match
      return {
        name: name?.trim() || "",
        url: url?.trim(),
        role: role?.trim(),
      }
    })
  }

  const postTeam = parseTeam(post?.metadata.team)

  if (!post) {
    notFound()
  }

  const [r, g, b] = post.metadata.color ? post.metadata.color.split(',') : [59, 130, 246]; // Default to blue if no color provided

  return (
    <section>
      <div
        className="absolute inset-0 z-0 h-screen opacity-50 pointer-events-none"
      style={{ backgroundImage: `radial-gradient(circle farthest-side at 50% 0, rgba(${r}, ${g}, ${b}, .5), rgba(0, 0, 0, 0))`}}><div className="
        absolute inset-0 
        z-20 
        opacity-20 
        mix-blend-overlay 
        bg-[url('/noise-overlay.png')] 
      "></div></div>
      <div className="flex flex-col justify-center items-center mt-2 mb-8 text-sm">
        <ViewTransition name={`post-title-${post.slug}`}>
          <h2 className="title font-semibold text-3xl text-center tracking-tighter">
            {post.metadata.title}
          </h2>
        </ViewTransition>
        <ViewTransition name={`post-date-${post.slug}`}>
          <span className="text-sm text-neutral-600 dark:text-neutral-400">
            {formatDate(post.metadata.publishedAt!)} • {post.metadata.tags?.join(', ')}
          </span>
        </ViewTransition>
      </div>
      <div className="relative flex justify-center items-center">
        <img
          src="/mockup-bg.png"
          alt="MacBook Mockup Background"
          className="w-full hidden dark:block"
        />
        <img
          src="/mockup-bg-light.png"
          alt="MacBook Mockup Background"
          className="w-full block dark:hidden"
        />
        <div className="absolute top-2 left-0 w-full h-full flex justify-center items-center">
          <div className="w-[85%]">
            <Safari
              url={Config.baseUrl}
              className="w-full rounded-lg shadow-lg"
              imageSrc={post.metadata.cover}
            />
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 my-8">
        <div>
          <span className="font-semibold text-xs mb-2 uppercase text-neutral-500 dark:text-neutral-400 tracking-tight"
          >Technologies</span>
          <p>{post.metadata.techStack?.join(', ') || 'Not specified'}</p>
          <span className="font-semibold text-xs mb-2 mt-4 uppercase text-neutral-500 dark:text-neutral-400 tracking-tight"
          >Team</span>
          <p>{postTeam.map((member, index) => (
            <span key={index}>
              {member.url ? (
                <a href={member.url} target="_blank" rel="noopener noreferrer">
                  {member.name}
                </a>
              ) : (
                member.name
              )}
              {member.role ? ` (${member.role})` : ''}
              {index < (Array.isArray(postTeam) ? postTeam.length - 1 : 0) ? ', ' : ''}
            </span>
          ))}</p>
          <span className="font-semibold text-xs mb-2 mt-4 uppercase text-neutral-500 dark:text-neutral-400 tracking-tight"
          >Timeline & Status</span>
          <p>{post.metadata.timeline || 'No timeline available'}</p>
        </div>
        <div>
          <span className="font-semibold text-xs mb-2 uppercase text-neutral-500 dark:text-neutral-400 tracking-tight"
          >Overview</span>
          <p>{post.metadata.summary}</p>
        </div>
      </div>
      <article className="prose">
        <CustomMDX source={post.content} />
      </article>
    </section>
  )
}