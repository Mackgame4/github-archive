import Config from '@/lib/config';
import { getBlogPosts } from '@/lib/blog';

export function GET() {
  const blogPosts = getBlogPosts();
  const sortedPosts = blogPosts.sort((a, b) => {
    if (new Date(a.metadata.publishedAt!) > new Date(b.metadata.publishedAt!)) {
      return -1;
    }
    return 1;
  });

  const itemsXml = sortedPosts.map((post) =>
      `<item>
        <title>${post.metadata.title}</title>
        <link>${Config.baseUrl}/blog/${post.slug}</link>
        <description>${post.metadata.summary || ''}</description>
        <pubDate>${new Date(
          post.metadata.publishedAt!
        ).toUTCString()}</pubDate>
      </item>`
  )
  .join('\n');

  const rssFeed = `<?xml version="1.0" encoding="UTF-8" ?>
  <rss version="2.0">
    <channel>
        <title>${Config.title} RSS Feed</title>
        <link>${Config.baseUrl}</link>
        <description>RSS Feed for ${Config.description}</description>
        ${itemsXml}
    </channel>
  </rss>`;

  return new Response(rssFeed, {
    headers: {
      'Content-Type': 'text/xml',
    }
  });
}