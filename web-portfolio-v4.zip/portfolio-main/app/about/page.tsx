import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowRight, Code, Laptop, Sparkles } from "lucide-react"

export const metadata = {
  title: "About",
  description: "Read more about me and my work.",
}

export default function Page() {
  return (
    <section className="space-y-16">
      {/* Hero */}
      <div className="space-y-6 max-w-2xl">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
          Hey, I’m <span className="text-primary">Fábio Magalhães</span> 👋
        </h1>
        <p className="text-neutral-700 dark:text-neutral-300 text-lg leading-relaxed">
          I’m a software developer who loves turning ideas into clean, functional
          and enjoyable digital experiences. I care deeply about performance,
          simplicity, and writing code that actually lasts.
        </p>
        <div className="flex gap-3">
          <Badge variant="secondary">Software Engineering</Badge>
          <Badge variant="secondary">Problem Solver</Badge>
        </div>
      </div>

      {/* What I do */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="rounded-2xl">
          <CardContent className="p-6 space-y-4">
            <Code className="h-6 w-6" />
            <h3 className="font-semibold text-lg">Build</h3>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              I build modern web applications using technologies like Next.js,
              TypeScript, and Node.js, always focusing on maintainability and
              scalability.
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardContent className="p-6 space-y-4">
            <Laptop className="h-6 w-6" />
            <h3 className="font-semibold text-lg">Design & UX</h3>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              I enjoy crafting interfaces that feel intuitive and polished,
              usually with Tailwind CSS and component systems like shadcn/ui.
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardContent className="p-6 space-y-4">
            <Sparkles className="h-6 w-6" />
            <h3 className="font-semibold text-lg">Learn & Improve</h3>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Technology never stands still — and neither do I. I’m constantly
              learning, experimenting, and refining my skills.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Personal note */}
      <Card className="rounded-2xl">
        <CardContent className="p-8 space-y-4 max-w-3xl">
          <h2 className="text-xl font-semibold">A bit more about me</h2>
          <p className="text-neutral-700 dark:text-neutral-300 leading-relaxed">
            When I’m not coding, I enjoy exploring new ideas, improving existing
            systems, and understanding how things work under the hood. I believe
            good software is not just about features — it’s about clarity,
            reliability, and user trust.
          </p>
          <p className="text-neutral-700 dark:text-neutral-300 leading-relaxed">
            This blog is where I share what I learn, what I build, and the lessons
            I pick up along the way.
          </p>
        </CardContent>
      </Card>

      {/* CTA */}
      <div className="flex justify-start">
        <Button className="rounded-xl">
          Read the blog <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </section>
  )
}
