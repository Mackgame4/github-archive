import type { Metadata } from "next";
import { Lexend } from "next/font/google";
import { ThemeProvider } from "@/app/provider";
import Config from '@/lib/config';
import "./globals.css";
import { Navbar } from '@/components/navbar';
import Footer from "@/components/footer";
import { Analytics } from "@vercel/analytics/next";
import { SpeedInsights } from '@vercel/speed-insights/next';

const lexend = Lexend({
  subsets: ["latin"],
  variable: "--font-sans",
});

export const metadata: Metadata = {
  title: Config.title,
  description: Config.description,
  metadataBase: new URL(Config.baseUrl),
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang={Config.lang} suppressHydrationWarning>
      <body className={`${lexend.className} min-h-screen antialiased`}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          <main className="max-w-3xl px-6 pt-8 mx-auto min-w-0">
            <Navbar />
            {children}
            <Footer />
          </main>
        </ThemeProvider>
        <Analytics />
        <SpeedInsights />
      </body>
    </html>
  );
}
