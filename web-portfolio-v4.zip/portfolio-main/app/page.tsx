import Image from "next/image";
import { Button } from "@/components/ui/button";
import { BlogPosts } from '@/components/posts'

export default function Home() {
  return (
    <main className="">
      <BlogPosts />
    </main>
  );
}
